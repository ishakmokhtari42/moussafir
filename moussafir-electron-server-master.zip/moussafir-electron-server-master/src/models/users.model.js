const NeDB = require('nedb');
const path = require('path');

module.exports = function (app) {
  const dbPath = app.get('nedb');
  const Model = new NeDB({
    filename: path.join(dbPath, 'users.db'),
    autoload: true
  });

  Model.ensureIndex({ fieldName: 'email', unique: true });

  //look if the admin exists, if not create one with admin role
  Model.find({email:'admin'},function(err,docs){
    if(docs.length === 0){
      Model.insert({email:'admin', role: "admin",password:"$2a$10$7c6bqQpIaM2QzhDhl1xaQelZPwwQk2o40F70DBaPBDWDtmHbgQhqi"})
    }
  });

  Model.find({email:'super-admin'},function(err,docs){
    if(docs.length === 0){
      Model.insert({email:'super-admin', role: "super-admin",password:"$2a$10$WHio6Zg16TxTGkRVGOD1jONP76Z0QzhzU0KxMdX4v1urLR4.Jkcae"})
    }
  });
  return Model;
};
