const { authenticate } = require('feathers-authentication').hooks;

module.exports = {
  before: {
    all: [
      authenticate('jwt'),
      function (hook) {
        if(!hook.data.userId) 
          hook.data.userId = hook.params.user._id;
        return hook;
      }
    ],
    find: [],
    get: [],
    create: [],
    update: [],
    patch: [],
    remove: []
  },

  after: {
    all: [],
    find: [],
    get: [],
    create: [],
    update: [],
    patch: [],
    remove: []
  },

  error: {
    all: [],
    find: [],
    get: [],
    create: [],
    update: [],
    patch: [],
    remove: []
  }
};
