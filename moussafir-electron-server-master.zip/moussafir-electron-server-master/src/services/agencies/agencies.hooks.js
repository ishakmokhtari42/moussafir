const { authenticate } = require('feathers-authentication').hooks;
const errors = require('feathers-errors');

var restrictToRole = function (roles) {
  return function (hook) {
    return hook.app.service('users').find({
      query: {_id: hook.params.payload.userId}
    }).then(page => {
      if (page.length !== 0) {
        if (!roles.includes(page[0].role)) {
          throw new errors.Forbidden(new Error('You are not authorized to access this information'));
        }
      }
      return hook;
    });
  }
}

module.exports = {
  before: {
    all: [ authenticate('jwt')],
    find: [],
    get: [],
    create: [restrictToRole(['super-admin', 'admin'])],
    update: [restrictToRole(['super-admin', 'admin'])],
    patch: [restrictToRole(['super-admin', 'admin'])],
    remove: [restrictToRole(['super-admin', 'admin'])]
  },

  after: {
    all: [],
    find: [],
    get: [],
    create: [],
    update: [],
    patch: [],
    remove: []
  },

  error: {
    all: [],
    find: [],
    get: [],
    create: [],
    update: [],
    patch: [],
    remove: []
  }
};
