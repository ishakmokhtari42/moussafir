// Initializes the `trips` service on path `/trips`
const createService = require('feathers-nedb');
const createModel = require('../../models/trips.model');
const hooks = require('./trips.hooks');
const filters = require('./trips.filters');

module.exports = function () {
  const app = this;
  const Model = createModel(app);
  const paginate = app.get('paginate');

  const options = {
    name: 'trips',
    Model,
    paginate
  };

  // Initialize our service with any options it requires
  app.use('/trips', createService(options));

  // Get our initialized service so that we can register hooks and filters
  const service = app.service('trips');

  service.hooks(hooks);

  if (service.filter) {
    service.filter(filters);
  }
};
