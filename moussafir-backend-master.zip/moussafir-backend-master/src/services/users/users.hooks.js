const { authenticate } = require('feathers-authentication').hooks;
const commonHooks = require('feathers-hooks-common');
const { restrictToOwner } = require('feathers-authentication-hooks');
const path = require('path');
const errors = require('feathers-errors');

const { hashPassword } = require('feathers-authentication-local').hooks;
const restrict = [
  authenticate('jwt'),
  restrictToOwner({
    idField: '_id',
    ownerField: '_id'
  })
];

var restrictToRole = function (roles) {
  return function (hook) {
    return hook.app.service('users').find({
      query: {_id: hook.params.payload.userId}
    }).then(page => {
      if (page.length !== 0) {
        if (!roles.includes(page[0].role)) {
          throw new errors.Forbidden(new Error('You are not authorized to access this information'));
        }
      }
      return hook;
    });
  }
}

var maxUsers = function (maxUsersAllowed) {
  return function (hook) {
    return hook.app.service('users').find({}).then(page => {
      if (page.length - 2 >= maxUsersAllowed) {
        throw new errors.Forbidden(new Error('You can not add other users'));
      }
      return hook;
    });
  }
}

module.exports = {
  before: {
    all: [authenticate('jwt')],
    find: [],
    get: [ /*...restrict*/],
    create: [hashPassword(), restrictToRole(['super-admin', 'admin']), maxUsers(3)],
    update: [hashPassword(), restrictToRole(['super-admin', 'admin'])],
    patch: [hashPassword(), restrictToRole(['super-admin', 'admin'])],
    remove: [restrictToRole(['super-admin'])]
  },

  after: {
    all: [
      commonHooks.when(
        hook => hook.params.provider,
        commonHooks.discard('password')
      )
    ],
    find: [],
    get: [],
    create: [],
    update: [],
    patch: [],
    remove: []
  },

  error: {
    all: [],
    find: [],
    get: [],
    create: [],
    update: [],
    patch: [],
    remove: []
  }
};
