// Initializes the `printing-numbers` service on path `/printing-numbers`
const createService = require('feathers-nedb');
const createModel = require('../../models/printing-numbers.model');
const hooks = require('./printing-numbers.hooks');
const filters = require('./printing-numbers.filters');

module.exports = function () {
  const app = this;
  const Model = createModel(app);
  const paginate = app.get('paginate');

  const options = {
    name: 'printing-numbers',
    Model,
    paginate
  };

  // Initialize our service with any options it requires
  app.use('/printing-numbers', createService(options));

  // Get our initialized service so that we can register hooks and filters
  const service = app.service('printing-numbers');

  service.hooks(hooks);

  if (service.filter) {
    service.filter(filters);
  }
};
