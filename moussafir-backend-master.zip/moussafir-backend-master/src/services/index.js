const clients = require('./clients/clients.service.js');
const suppliers = require('./suppliers/suppliers.service.js');
const products = require('./products/products.service.js');
const trips = require('./trips/trips.service.js');
const users = require('./users/users.service.js');
const agencies = require('./agencies/agencies.service.js');
const printingNumbers = require('./printing-numbers/printing-numbers.service.js');
module.exports = function () {
  const app = this; // eslint-disable-line no-unused-vars
  app.configure(clients);
  app.configure(suppliers);
  app.configure(products);
  app.configure(trips);
  app.configure(users);
  app.configure(agencies);
  app.configure(printingNumbers);
};
