const assert = require('assert');
const app = require('../../src/app');

describe('\'printing-numbers\' service', () => {
  it('registered the service', () => {
    const service = app.service('printing-numbers');

    assert.ok(service, 'Registered the service');
  });
});
