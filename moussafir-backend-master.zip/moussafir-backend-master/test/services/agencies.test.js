const assert = require('assert');
const app = require('../../src/app');

describe('\'agencies\' service', () => {
  it('registered the service', () => {
    const service = app.service('agencies');

    assert.ok(service, 'Registered the service');
  });
});
