const {
  app,
  BrowserWindow
} = require('electron')
const path = require('path')
const url = require('url')

// set up ======================================================================
var express = require('express');
var server = express(); // create our app w/ express
var port = process.env.PORT || 4040; // set the port
var morgan = require('morgan');
var bodyParser = require('body-parser');
var methodOverride = require('method-override');

// Keep a global reference of the window object, if you don't, the window will
// be closed automatically when the JavaScript object is garbage collected.
let win

function createWindow() {
  // configuration ===============================================================
  server.use(express.static('./resources/app.asar/public')); // set the static files location /public/img will be /img for users
  server.use(morgan('dev')); // log every request to the console
  server.use(bodyParser.urlencoded({
    'extended': 'true'
  })); // parse application/x-www-form-urlencoded
  server.use(methodOverride('X-HTTP-Method-Override')); // override with the X-HTTP-Method-Override header in the request


  // routes ======================================================================
  server.get('/', function (req, res) {
    res.sendFile(__dirname + '/resources/app.asar/public/index.html'); // load the single view file (angular will handle the page changes on the front-end)
  });
  server.get('*', function (req, res) {
    res.sendFile(__dirname + '/resources/app.asar/public/main.html'); // load the single view file (angular will handle the page changes on the front-end)
  });
  // listen (start app with node server.js) ======================================
  server.listen(port);

  /* eslint-disable no-console */

  // Create the browser window.
  win = new BrowserWindow({
    width: 800,
    height: 600,
    webPreferences: {
      devTools: true
    }
    // icon: __dirname + "/public/assets/img/app/my-app-logo.png"
  })

  win.maximize();

  // and load the index.html of the app.
  win.loadURL('http://localhost:4040/');
  win.focus();
  // Emitted when the window is closed.
  win.on('closed', () => {
    // Dereference the window object, usually you would store windows
    // in an array if your app supports multi windows, this is the time
    // when you should delete the corresponding element.
    win = null
  })
}

// This method will be called when Electron has finished
// initialization and is ready to create browser windows.
// Some APIs can only be used after this event occurs.
app.on('ready', createWindow)

// Quit when all windows are closed.
app.on('window-all-closed', () => {
  // On macOS it is common for applications and their menu bar
  // to stay active until the user quits explicitly with Cmd + Q
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

app.on('activate', () => {
  // On macOS it's common to re-create a window in the app when the
  // dock icon is clicked and there are no other windows open.
  if (win === null) {
    createWindow()
  }
})

// In this file you can include the rest of your app's specific main process
// code. You can also put them in separate files and require them here.