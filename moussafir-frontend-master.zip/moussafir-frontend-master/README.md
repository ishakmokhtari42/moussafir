# Moussafir Angular admin panel front-end framework

## Features
* Responsive layout
* High resolution
* Bootstrap CSS Framework
* Sass
* Gulp build
* AngularJS
* Jquery
* etc

### From Moussafir
