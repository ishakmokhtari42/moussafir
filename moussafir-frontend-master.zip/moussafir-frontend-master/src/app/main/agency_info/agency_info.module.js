(function () {
	'use strict';

	angular
		.module('main.agency_info', [])
		.config(config);

	function config($stateProvider) {
		$stateProvider
			.state('agency_info', {
				parent: 'main',
				url: '/agency-info',
				templateUrl: 'app/main/agency_info/agency_info.html',
				title: 'Information d\'agence',
				translate: "home.agency_info",
				controller: "AgencyController",
				controllerAs: "agencyVm",
				// sidebarMeta: {
				// 	roles: ['admin', 'super-admin']
				// },
				// loginRequired: true,
				// adminRequired: true
			});
	}
})();