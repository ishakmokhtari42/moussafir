(function () {
	'use strict';

	angular
		.module('main.agency_info')
		.controller('AgencyController', AgencyController);

	function AgencyController(AgencyService, ErrorToast, $state, toastr) {
		var vm = this;

		AgencyService.query(function (data) {
			if (data.length > 0) {
				vm.agency = data[0];
				vm.agency_id = vm.agency._id;
				vm.agency_logo = vm.agency.logo;
			}
		}, function (error) {
			ErrorToast(error);
		});

		vm.save = save;
		vm.cancel = cancel;

		function getBase64(file, callback) {
			vm.reader = new FileReader();
			vm.reader.readAsDataURL(file);
			vm.reader.onload = callback;
		}

		function save(redirect) {
			if (typeof vm.agency_logo === 'string') {
				(vm.agency_id ? updateAgency : addAgency)(redirect);
			} else {
				getBase64(vm.agency_logo, function () {
					vm.agency.logo = angular.copy(vm.reader.result);
					(vm.agency_id ? updateAgency : addAgency)(redirect);
				});
			}
		}

		function addAgency(redirect) {
			vm.agency.date = (new Date()).toISOString();
			AgencyService.save(vm.agency, function (data) {
				vm.agency._id = data._id;
				vm.agency_id = data._id;
				toastr.success('Les information de l\'agence ont été modifier avec succès', 'Succès');
				if(redirect)
				$state.go('dashboard');
			}, function (error) {
				ErrorToast(error);
			});
		}

		function updateAgency(redirect) {
			vm.agency.date = vm.agency.date || (new Date()).toISOString();
			AgencyService.update({
				agencyId: vm.agency_id
			}, vm.agency, function (data) {
				toastr.success('Les information de l\'agence ont été modifier avec succès', 'Succès');
				if(redirect)$state.go('dashboard');
			}, function (error) {
				ErrorToast(error);
			});
		}

		function cancel() {
			$state.go('dashboard');
		}

	}
})();