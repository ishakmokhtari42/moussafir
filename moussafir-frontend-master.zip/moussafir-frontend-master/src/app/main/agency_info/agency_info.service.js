(function () {
	'use strict';

	angular
		.module('main.agency_info')
		.factory('AgencyService', AgencyService);

	function AgencyService($resource, $window) {
		var api_endpoint = $window.localStorage['host'];
		return $resource(api_endpoint + 'agencies/:agencyId', {
			agencyId: '@id'
		}, {
			update: {
				method: 'PUT'
			}
		})
	}
})();