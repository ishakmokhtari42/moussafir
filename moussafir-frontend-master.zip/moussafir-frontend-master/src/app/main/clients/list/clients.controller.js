(function () {
	'use strict';

	angular.module('main.clients')
		.controller('ClientsController', ClientsController);

	function ClientsController(ClientService, ProductService, UserService, TripService, toastr, ErrorToast, dialogs) {
		var vm = this;

		vm.clients = [];
		vm.products = [];
		vm.filteredClients = [];
		vm.selectedTypes = [];
		vm.selectedUsers = [];
		vm.clientTypes = [
			"Particulier",
			"Agence de voyage",
			"Entreprise",
			"Autre"
		]

		ProductService.query(function (data) {
			vm.products = data;
			TripService.query(function (data) {
				vm.trips = data;
				getClients();
			}, function (error) {
				ErrorToast(error);
			});
		}, function (error) {
			ErrorToast(error);
		});

		UserService.query({
			'$select[]': 'email',
			'$select': 'role'
		}, function (data) {
			vm.users = data;
			for (var i = 0; i < vm.users.length; i++) {
				if (vm.users[i].role === "super-admin") {
					vm.users.splice(i, 1);
					break;
				}
			}
		}, function (error) {
			ErrorToast(error);
		});

		vm.deleteClient = deleteClient;
		vm.filter = filter;
		vm.getClientProducts = getClientProducts;

		function filter() {
			vm.filteredClients = vm.clients.filter(function (client) {
				return (vm.selectedUsers.length > 0 ? vm.selectedUsers.includes(client.userId) : true) && (vm.withRest ? client.rest > 0 : true) && (vm.selectedTypes.length > 0 ? vm.selectedTypes.includes(client.type) : true);
			})
		}

		function getClients() {
			ClientService.query({
				'$select': ['type', 'username', 'date', 'userId']
			}, function (data) {
				vm.clients = data;
				vm.clients.forEach(function (client) {
					client.sales = 0;
					client.rest = 0;
					vm.products.forEach(function (product) {
						if (product.client === client._id) {
							client.sales += product.total || 0;
							client.rest += (product.total || 0) - (product.paid_amount || 0);
						}
					});



				});
				vm.trips.forEach(function (trip) {
					trip.groups.forEach(function (group) {
						angular.forEach(group.clients, function (client_info) {
							var client = vm.clients.find(function (clt) {
								return clt._id === client_info._id;
							});
							if (client && client_info.products) {
								client.sales += client_info.products.total || 0;
								client.rest += (client_info.products.total || 0) - (client_info.products.paid_amount || 0);
							}
						});
					});
				});
				vm.filteredClients = vm.clients;
			}, function (error) {
				ErrorToast(error);
			});
		}

		function deleteClient(clientId) {
			var dialog = dialogs.confirm('Confirmation', 'Vous allez supprimer le client!', {
				keyboard: true
			});
			dialog.result.then(function () {
				ClientService.delete({
					clientId: clientId
				}, function (data) {
					toastr.success('Le client a été supprimer avec succès', 'Succès');
					for (var i = 0; i < vm.clients.length; i++) {
						if (vm.clients[i]._id === clientId) {
							vm.clients.splice(i, 1);
							break;
						}
					}
				}, function (error) {
					ErrorToast(error);
				})
			});
		}

		function getClientProducts(client) {
			vm.clientProducts = vm.products.filter(function (product) {
				return product.client === client._id;
			});

			vm.clientTrips = vm.trips.filter(function (trip) {
				for (var groupIndex in trip.groups) {
					var group = trip.groups[groupIndex];
					for (var clientIndex in group.clients) {
						var client_info = group.clients[clientIndex];
						if (client_info._id === client._id) return true;
					}
				}
				return false;
			});

			dialogs.create('app/main/clients/list/dialogs/products-dialog.html', 'ClientProductsController', {
				products: vm.clientProducts,
				trips: vm.clientTrips,
				client: client
			}, {
				keyboard: true,
				size: 'md'
			}, 'dialogVm');
		}
	}
})();