(function () {
	'use strict';

	angular
		.module('main.trips')
		.controller('TripController', TripController);

	function TripController($state, $stateParams, $window, AgencyService, TripService, SupplierService, ClientService, RoomingPrintService, BusPrintService, ClientPrintService, NextPrintNumber, PlanePrintService, toastr, ErrorToast, dialogs) {
		var vm = this;

		vm.suppliers = [];
		vm.clients = [];
		vm.entrepriseClients = [];
		vm.trip = {
			nb_groups: 1,
			products: {},
			selectedProducts: [],
			groups: [{
				road_transport: {},
				hotel: {},
				plane_ticket: {},
				products: {},
				clients: []
			}]
		};
		vm.startGroupPage = 0;
		vm.startClientPage = 0

		// fetch suppliers
		SupplierService.query({
			'$select[]': 'username'
		}, function (data) {
			vm.suppliers = data;
		}, function (error) {
			ErrorToast(error);
		});

		AgencyService.query(function (data) {
			if (data.length > 0) {
				vm.agency = data[0];
			}
		}, function (error) {
			ErrorToast(error);
		});

		vm.new_client = {
			type: "Particulier",
			addresses: [null],
			phone_numbers: [null],
			fax_numbers: [null],
			web_sites: [null],
			emails: [null],
			passport: {}
		};

		vm.initGroup = function (index) {
			if (vm.trip.groups) {
				vm.trip.groups[index.toString()] = vm.trip.groups[index.toString()] || {
					products: {},
					clients: []
				}
			}
		}
		

		function getNights(from, to) {
			if (!from || !to) return 0;
			return moment.duration(moment(to).diff(moment(from))).asDays();
		}

		vm.products = [{
				title: "Réservation d’hôtel",
				name: 'hotel'
			},
			{
				title: "Billet d’avion",
				name: 'plane_ticket'
			},
			{
				title: "Transport routier",
				name: 'road_transport'
			},
			{
				title: "Vente simple",
				name: 'other'
			}
		];

		vm.currentGroup = "0";
		vm.currentClientGroup = "0";

		vm.trip_id = $stateParams.id;

		if (vm.trip_id) {
			TripService.get({
				tripId: vm.trip_id
			}, function (data) {
				vm.trip = data;
				if (vm.trip.stay) {
					vm.trip.stay.start_date = getDate(vm.trip.stay.start_date);
					vm.trip.stay.end_date = getDate(vm.trip.stay.end_date);
				}
				vm.trip.groups = vm.trip.groups.map(function (group) {
					if (group.stay) {
						group.stay.start_date = getDate(group.stay.start_date);
						group.stay.end_date = getDate(group.stay.end_date);
					}
					if (contains('plane_ticket')) {
						group.plane_ticket = group.plane_ticket || {};
						var plane_ticket = group.plane_ticket;
						plane_ticket.departure_date_from = getDate(plane_ticket.departure_date_from);
						plane_ticket.departure_time_from = getDate(plane_ticket.departure_time_from);
						plane_ticket.arrival_date_from = getDate(plane_ticket.arrival_date_from);
						plane_ticket.arrival_time_from = getDate(plane_ticket.arrival_time_from);

						plane_ticket.departure_date_to = getDate(plane_ticket.departure_date_to);
						plane_ticket.departure_time_to = getDate(plane_ticket.departure_time_to);
						plane_ticket.arrival_date_to = getDate(plane_ticket.arrival_date_to);
						plane_ticket.arrival_time_to = getDate(plane_ticket.arrival_time_to);
					}
					return group;
				});
			}, function (error) {
				ErrorToast(error);
			});
		}

		ClientService.query({
			'$select[]': 'username',
			'$select': 'type'
		}, function (data) {
			vm.clients = data;
		}, function (error) {
			ErrorToast(error);
		});
		vm.saveClient = saveClient;
		vm.addClient = addClient;
		vm.addGroup = addGroup;
		vm.range = range;
		vm.convert = convert;
		vm.getClient = getClient;
		vm.getDate = getDate;
		vm.save = save;
		vm.cancel = cancel;
		vm.editClientProducts = editClientProducts;
		vm.groupPrint = groupPrint;
		vm.clientPrint = clientPrint;
		vm.contains = contains;
		vm.getOccupantsCount = getOccupantsCount;
		vm.transportTypeChange = transportTypeChange; // for the bus
		vm.deleteClientProducts = deleteClientProducts;
		vm.addClientToGroup = addClientToGroup;
		vm.deleteClient = deleteClient;
		vm.getNights = getNights;

		function addClientToGroup() {
			vm.trip.groups[vm.currentGroup].clients.unshift({
				_id: vm.tripClient.clientId,
				selectedOccupants: vm.tripClient.selectedOccupants
			});
			vm.tripClient = null;
		}

		function deleteClient(index) {
			vm.trip.groups[vm.currentGroup].clients.splice(index, 1);
		}

		function getOccupantsCount(group) {
			var occupantsCount = 0;
			group.clients.forEach(function (client) {
				if (client.selectedOccupants) occupantsCount += client.selectedOccupants.length;
			});

			return occupantsCount;
		}

		function contains(string) {
			for (var i = 0; i < vm.trip.selectedProducts.length; i++) {
				if (vm.trip.selectedProducts[i] === string) {
					return true;
				}
			}
			return false;
		}

		function getClient(id) {
			return vm.clients.find(function (elem) {
				return elem._id === id
			});
		}

		function convert(number) {
			return parseInt(number) || 0;
		}

		function range(number) {
			return new Array(number);
		}

		function getDate(stringDate) {
			return stringDate ? new Date(stringDate) : NaN;
		}

		function addClient(groupe) {
			groupe.clients.push({
				occupants: []
			});
		}

		function addGroup() {
			vm.trip.nb_groups++;
			vm.currentGroup = (vm.trip.nb_groups - 1).toString();
		}

		function saveClient() {
			ClientService.save(vm.new_client, function (data) {
				toastr.success('Le client a été ajouté avec succès', 'Succès');
				vm.clients.push(data);
				vm.addClient = false;
				vm.new_client = {
					type: "Particulier",
					addresses: [null],
					phone_numbers: [null],
					fax_numbers: [null],
					web_sites: [null],
					emails: [null],
					passport: {}
				};
			}, function (error) {
				ErrorToast(error);
			});
		}

		function cancel() {
			$state.go("trips_list");
		}

		function save(redirect) {
			(vm.trip_id ? updateTrip : addTrip)(redirect);
		}

		function addTrip(redirect) {
			vm.trip.date = (new Date()).toISOString();
			TripService.save(vm.trip, function (data) {
				toastr.success('Le voyage organisé a été ajouté avec succès', 'Succès');
				vm.trip._id = vm.trip_id = data._id;
				if (redirect) $state.go("trips_list");
			}, function (error) {
				ErrorToast(error);
			});
		}

		function updateTrip(redirect) {
			vm.trip.date = vm.trip.date || (new Date()).toISOString();
			TripService.update({
				tripId: vm.trip_id
			}, vm.trip, function (data) {
				toastr.success('Le voyage organisé a été modifier avec succès', 'Succès');
				if (redirect) $state.go("trips_list");
			}, function (error) {
				ErrorToast(error);
			});
		}

		function deleteClientProducts(client) {
			var dialog = dialogs.confirm('Confirmation', 'Vous allez supprimer les produits du client : ' + getClient(client._id).username + " !", {
				keyboard: true
			});
			dialog.result.then(function () {
				client.products = {
					road_transport: {},
					plane_ticket: {},
					hotel: {}
				};
				updateTrip(false);
			});
		}

		function editClientProducts(client) {
			var group = vm.trip.groups[parseInt(vm.currentGroup)];

			vm.occupantsNumber = 0;
			group.clients.forEach(function (client) {
				vm.occupantsNumber += client.selectedOccupants.length;
			});

			client.products = client.products || {};

			vm.productModel = client.products;
			vm.productModel.stay = vm.productModel.stay || group.stay;
			vm.productModel.destination = vm.productModel.destination || vm.trip.destination;

			if (vm.contains('road_transport')) {
				client.products.road_transport = client.products.road_transport || {};
				angular.forEach(group.road_transport, function (value, key) {
					client.products.road_transport[key] = value;
				});
			}

			if (vm.contains('plane_ticket')) {
				client.products.plane_ticket = client.products.plane_ticket || {};
				angular.forEach(group.plane_ticket, function (value, key) {
					client.products.plane_ticket[key] = value;
				});
			}

			if (vm.contains('hotel')) {
				client.products.hotel = client.products.hotel || {};
				angular.forEach(group.hotel, function (value, key) {
					client.products.hotel[key] = value;
				});
			}

			vm.selectedProductsModel = angular.copy(vm.trip.selectedProducts);
			vm.selectedOccupants = client.selectedOccupants;
			vm.selectedProductText = "Client : " + getClient(client._id).username;
			vm.showForm = true;
		}

		function groupPrint() {
			var group = vm.trip.groups[parseInt(vm.currentClientGroup)];

			switch (vm.print_product_type) {
				case ('hotel'):
					RoomingPrintService.print(vm.agency.logo, vm.agency, vm.trip.name, vm.trip.date, parseInt(vm.currentGroup), group, vm.clients);
					break;

				case ('bus'):
					BusPrintService.print(vm.agency.logo, vm.agency, vm.trip.name, vm.trip.date, parseInt(vm.currentGroup), group, vm.clients);
					break;
				case ('plane'):
					PlanePrintService.print(vm.agency.logo, vm.agency, vm.trip.name, vm.trip.date, parseInt(vm.currentGroup), group, vm.clients);
					break;
			}
		}

		function clientPrint(client, devis) {
			var group = vm.trip.groups[parseInt(vm.currentClientGroup)];

			if (vm.agency) {
				if (vm.contains('hotel')) {
					client.products.hotel = client.products.hotel || {};
					angular.forEach(group.hotel, function (value, key) {
						client.products.hotel[key] = value;
					});
				}

				if (vm.contains('road_transport')) {
					client.products.road_transport = client.products.road_transport || {};
					angular.forEach(group.road_transport, function (value, key) {
						client.products.road_transport[key] = value;
					});
				}

				if (vm.contains('plane_ticket')) {
					client.products.plane_ticket = client.products.plane_ticket || {};
					angular.forEach(group.plane_ticket, function (value, key) {
						client.products.plane_ticket[key] = value;
					});
				}

				NextPrintNumber.get(function (dailyCount, totalCount) {
					ClientPrintService.print(devis, dailyCount, totalCount, vm.agency.logo, vm.agency, vm.trip.name, vm.trip.date, vm.trip.selectedProducts, vm.currentClientGroup, group, client, vm.clients
						// ,function () {
						// 	if (!devis) {
						// 		// client.disable_delete = true;
						// 		updateTrip(false);
						// 	}
						// }
					);
				});
			} else {
				$state.go('agency_info');
				toastr.warning('Vous devez remplir les information de l\'agence', 'Attention!');
			}
		}

		function transportTypeChange() {
			var group = vm.trip.groups[parseInt(vm.currentGroup)];
			switch (group.road_transport.type) {
				case ('Bus 47'):
					group.road_transport.nb_places = 47;
					break;
				case ('Bus 50'):
					group.road_transport.nb_places = 50;
					break;
				case ('Bus 54'):
					group.road_transport.nb_places = 54;
					break;
			}
		}
	}
})();