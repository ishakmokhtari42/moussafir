(function () {
	'use strict';

	angular
		.module('main.trips')
		.directive('productForm', productForm);

	function productForm(ProductService, CalculationService, ClientService, ErrorToast, toastr) {
		return {
			restrict: 'E',
			scope: {
				product: '=ngModel',
				selectedProducts: '=',
				selectedOccupants: '=',
				occupantsNumber: '=',
				clients: '=',
				showForm: '=',
				submit: '&'
			},
			templateUrl: 'app/main/trips/trip/product-form/product.html',
			link: function (scope) {
				var vm = scope;
				if (vm.product) updateProductInfo();

				//i'm really sorry for not being DRY
				var cal = CalculationService;

				vm.suppliers = [];
				vm.companies = [];

				vm.product = vm.product || {
					stay: {},
					destination: "",
					hotel: {
						nb_rooms: 1
					},
					plane_ticket: {
						nb_stops: 0
					},
					road_transport: {
						nb_stops: 0
					}
				};

				vm.product.hotel = vm.product.hotel || {};
				vm.product.ranting = vm.product.ranting || {};
				vm.product.plane_ticket = vm.product.plane_ticket || {};
				vm.product.ship_ticket = vm.product.ship_ticket || {};
				vm.product.road_transport = vm.product.road_transport || {};
				vm.product.other = vm.product.other || {};
				vm.product.visa = vm.product.visa || {};
				vm.product.stay = vm.product.stay || {};

				cal.init(function () {
					return {
						product: vm.product,
						rooms: vm.rooms,
						occupant: getOccupant
					}
				});

				vm.subDates = subDates;
				vm.range = range;
				vm.update = update;
				vm.updateAll = updateAll;
				vm.cancel = cancel;
				vm.getRooms = getRooms;
				vm.contains = contains;
				vm.getOccupant = getOccupant;
				vm.getNights = getNights;
				vm.totalPrice = totalPrice;
				vm.hotelPriceByOccupant = cal.hotelPriceByOccupant;
				vm.hotelPriceByRoom = cal.hotelPriceByRoom;
				vm.hotelTotalPriceByRoom = cal.hotelTotalPriceByRoom;
				vm.roadPriceByOccupant = cal.roadPriceByOccupant;
				vm.planePriceByOccupant = cal.planePriceByOccupant;
				vm.insurencePriceByOccupant = cal.insurencePriceByOccupant;
				vm.ratingPriceByOccupant = cal.ratingPriceByOccupant;
				vm.shipPriceByOccupant = cal.shipPriceByOccupant;
				vm.transportTypeChange = transportTypeChange;

				// added by Tetti

				vm.totalHotelPrice = cal.totalHotelPrice;
				vm.totalHotelPriceChange = totalHotelPriceChange;
				vm.totalPlane_ticketPrice = cal.totalPlanePrice;
				vm.totalPlane_ticketPriceChange = totalPlane_ticketPriceChange;
				vm.totalRantingPrice = cal.totalRatingPrice;
				vm.totalRantingPriceChange = totalRantingPriceChange;
				vm.totalRoad_transportPrice = cal.totalRoadTravelPrice;
				vm.totalRoad_transportPriceChange = totalRoad_transportPriceChange;
				vm.totalShip_ticketPrice = cal.totalShipPrice;
				vm.totalShip_ticketPriceChange = totalShip_ticketPriceChange;
				vm.totalVente = totalVente;
				vm.totalAchat = totalAchat;
				vm.totalSimplePriceChange = totalSimplePriceChange;



				function totalPrice() {
					var price = 0;
					if (vm.product) {
						price += contains('hotel') ? cal.totalHotelPrice()(1 + ((vm.product.hotel.total_profit || 0) / 100)) || 0 : 0;
						price += contains('ranting') ? cal.totalRatingPrice()(1 + ((vm.product.ranting.total_profit || 0) / 100)) || 0 : 0;
						price += contains('plane_ticket') ? cal.totalPlanePrice()(1 + ((vm.product.plane_ticket.total_profit || 0) / 100)) || 0 : 0;
						price += contains('travel_insurence') ? cal.totalInsurencePrice() || 0 : 0;
						price += contains('road_transport') ? cal.totalRoadTravelPrice()(1 + ((vm.product.road_transport.total_profit || 0) / 100)) || 0 : 0;
						price += contains('ship_ticket') ? cal.totalShipPrice()(1 + ((vm.product.ship_ticket.total_profit || 0) / 100)) || 0 : 0;
						price += contains('consulat') ? cal.consulatVisaPrice() || 0 : 0;
						price += contains('rendez_vous') ? cal.rendezVousPrice() || 0 : 0;
						price += contains("other") ? cal.totalOtherPrice() || 0 : 0;
						if (!vm.product.skipDetail) vm.product.purchase_price_default = price;
						vm.product.total_default = price;

						//vm.product.purchase_price = vm.product.purchase_price_default * vm.product.exchange_rate;
						vm.product.total = vm.product.total_default * vm.product.exchange_rate;
					}
					return price;
				}


				function totalVente() {
					var price = 0;
					price += vm.product.hotel.total || 0;
					price += vm.product.plane_ticket.total || 0;
					price += vm.product.other.total || 0;
					price += vm.product.ranting.total || 0;
					price += vm.product.road_transport.total || 0;
					price += vm.product.ship_ticket.total || 0;
					vm.product.total = price;

					return price;
				}

				function totalAchat() {
					var price = 0;
					price += vm.product.hotel.purchase_price || 0;
					price += vm.product.other.purchase_price || 0;
					price += vm.product.plane_ticket.purchase_price || 0;
					price += vm.product.ranting.purchase_price || 0;
					price += vm.product.road_transport.purchase_price || 0;
					price += vm.product.ship_ticket.purchase_price || 0;
					vm.product.purchase_price = price;

					return price;
				}

				function totalSimplePriceChange() {
					var price = 0;
					vm.product.other.purchase_price_default = cal.totalOtherPrice();
					vm.product.other.purchase_price = vm.product.other.purchase_price_default * vm.product.other.exchange_rate;
					vm.product.other.total_default = cal.totalOtherPrice() * (1 + ((vm.product.other.total_profit || 0) / 100));
					price = cal.totalOtherPrice() * vm.product.other.exchange_rate;
					vm.product.other.total = price * (1 + ((vm.product.other.total_profit || 0) / 100));
					return price;
				}

				function totalHotelPriceChange() {
					var price = 0;
					vm.product.hotel.purchase_price_default = cal.totalHotelPrice();
					vm.product.hotel.purchase_price = vm.product.hotel.purchase_price_default * vm.product.hotel.exchange_rate;
					vm.product.hotel.total_default = cal.totalHotelPrice() * (1 + ((vm.product.hotel.total_profit || 0) / 100));
					price = cal.totalHotelPrice() * vm.product.hotel.exchange_rate;
					vm.product.hotel.total = price * (1 + ((vm.product.hotel.total_profit || 0) / 100));
					return price;
				}

				function totalPlane_ticketPriceChange() {
					var price = 0;
					vm.product.plane_ticket.purchase_price_default = cal.totalPlanePrice();
					vm.product.plane_ticket.purchase_price = vm.product.plane_ticket.purchase_price_default * vm.product.plane_ticket.exchange_rate;
					vm.product.plane_ticket.total_default = cal.totalPlanePrice() * (1 + ((vm.product.plane_ticket.total_profit || 0) / 100));
					price = cal.totalPlanePrice() * vm.product.plane_ticket.exchange_rate;
					vm.product.plane_ticket.total = price * (1 + ((vm.product.plane_ticket.total_profit || 0) / 100));
					return price;
				}

				function totalRantingPriceChange() {
					var price = 0;
					vm.product.ranting.purchase_price_default = cal.totalRatingPrice();
					vm.product.ranting.purchase_price = vm.product.ranting.purchase_price_default * vm.product.ranting.exchange_rate;
					price = cal.totalRatingPrice() * vm.product.ranting.exchange_rate;
					vm.product.ranting.total = price * (1 + ((vm.product.ranting.total_profit || 0) / 100));
					return price;
				}

				function totalRoad_transportPriceChange() {
					var price = 0;
					vm.product.road_transport.purchase_price_default = cal.totalRoadTravelPrice();
					vm.product.road_transport.purchase_price = vm.product.road_transport.purchase_price_default * vm.product.road_transport.exchange_rate;
					vm.product.road_transport.total_default = cal.totalRoadTravelPrice() * (1 + ((vm.product.road_transport.total_profit || 0) / 100));
					price = cal.totalRoadTravelPrice() * vm.product.road_transport.exchange_rate;
					vm.product.road_transport.total = price * (1 + ((vm.product.road_transport.total_profit || 0) / 100));
					return price;
				}

				function totalShip_ticketPriceChange() {
					var price = 0;
					vm.product.ship_ticket.purchase_price_default = cal.totalShipPrice();
					vm.product.ship_ticket.purchase_price = vm.product.ship_ticket.purchase_price_default * vm.product.ship_ticket.exchange_rate;
					price = cal.totalShipPrice() * vm.product.ship_ticket.exchange_rate;
					vm.product.ship_ticket.total = price * (1 + ((vm.product.ship_ticket.total_profit || 0) / 100));
					return price;
				}


				function range(number) {
					return new Array(number);
				}

				function subDates(from, to) {
					var nights = getNights(from, to);
					return (nights === 0) ? 0 : (nights + 1);
				}

				function getNights(from, to) {
					if (!from || !to) return 0;
					return moment.duration(moment(to).diff(moment(from))).asDays();
				}

				function update(field, name) {
					if (vm.product[field].all) {
						angular.forEach(vm.product[field].occupants, (function (element) {
							element[name] = vm.product[field][name];
						}));
					}
				}

				function updateAll(field) {
					if (vm.product[field].all) {
						angular.forEach(vm.product[field].occupants, (function (element) {
							element['profit'] = vm.product[field]['profit'];
							element['unit_price'] = vm.product[field]['unit_price'];
						}));
					}
				}

				function transportTypeChange() {
					switch (vm.product.road_transport.type) {
						case ('Bus 47'):
							vm.product.road_transport.nb_places = 47;
							break;
						case ('Bus 50'):
							vm.product.road_transport.nb_places = 50;
							break;
					}
				}

				function cancel() {
					vm.showForm = false;
				}

				function getRooms() {
					vm.rooms = [];
					angular.forEach(vm.product.hotel.occupants, (function (value, key) {
						if (!vm.rooms.includes(value.room_number) && value.room_number && getOccupant(key))
							vm.rooms.push(value.room_number);
					}));
					return vm.rooms;
				}

				function contains(string) {
					for (var i = 0; i < vm.selectedProducts.length; i++) {
						if (vm.selectedProducts[i] === string) {
							return true;
						}
					}
					return false;
				}

				function getDate(stringDate) {
					return stringDate ? new Date(stringDate) : NaN;
				}

				function getOccupant(id) {
					return vm.clients.find(function (elem) {
						return elem._id === id
					});
				}

				function updateProductInfo() {
					vm.product.stay.start_date = getDate(vm.product.stay.start_date);
					vm.product.stay.end_date = getDate(vm.product.stay.end_date);

					if (contains('ship_ticket', vm.selectedProducts)) {
						var ship_ticket = vm.product.ship_ticket;
						ship_ticket.departure_date_from = getDate(ship_ticket.departure_date_from);
						ship_ticket.departure_time_from = getDate(ship_ticket.departure_time_from);
						ship_ticket.arrival_date_from = getDate(ship_ticket.arrival_date_from);
						ship_ticket.arrival_time_from = getDate(ship_ticket.arrival_time_from);
					}

					if (contains('plane_ticket', vm.selectedProducts)) {
						var plane_ticket = vm.product.plane_ticket;
						plane_ticket.departure_date_from = getDate(plane_ticket.departure_date_from);
						plane_ticket.departure_time_from = getDate(plane_ticket.departure_time_from);
						plane_ticket.arrival_date_from = getDate(plane_ticket.arrival_date_from);
						plane_ticket.arrival_time_from = getDate(plane_ticket.arrival_time_from);

						plane_ticket.departure_date_to = getDate(plane_ticket.departure_date_to);
						plane_ticket.departure_time_to = getDate(plane_ticket.departure_time_to);
						plane_ticket.arrival_date_to = getDate(plane_ticket.arrival_date_to);
						plane_ticket.arrival_time_to = getDate(plane_ticket.arrival_time_to);
					}
				}
			}
		}
	}
})();