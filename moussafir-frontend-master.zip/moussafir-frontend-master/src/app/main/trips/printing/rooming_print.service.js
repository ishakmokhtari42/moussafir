(function () {
	'use strict';

	angular
		.module('main.trips')
		.factory('RoomingPrintService', RoomingPrintService);

	function RoomingPrintService(CalculationService, $rootScope, toastr) {
		var vm = this;

		return {
			print: print
		}

		function getClient(id) {
			return vm.clients.find(function (elem) {
				return elem._id === id
			});
		}

		function getNights(from, to) {
			if (!from || !to) return 0;
			return moment.duration(moment(to).diff(moment(from))).asDays();
		}

		function getOccupantsTable(group) {

			var table = {
				columns: [{
					title: "N°",
					dataKey: "index"
				}, {
					title: "Nté",
					dataKey: "nights"
				}, {
					title: "Nom Complet",
					dataKey: "username"
				}, {
					title: "Personne",
					dataKey: "occupant_type"
				}, {
					title: "Chambre",
					dataKey: "room_type"
				}, {
					title: "Arrangement",
					dataKey: "supplement_type"
				}, {
					title: "VENTE",
					dataKey: "purchase_price"
				}, {
					title: "voucher",
					dataKey: "voucher"
				}, {
					title: "Indication",
					dataKey: 'indication'
				}],
				rows: []
			};

			vm.total_group = -(group.hotel.freebies_amount || 0);
			vm.statictics = {
				occupants: 0,
				adults: 0,
				kids: 0,
				babies: 0
			};

			angular.forEach(group.clients, function (client, clientIndex) {
				if (client.products) {
					var nights = client.stay ? getNights(client.products.stay.start_date, client.products.stay.end_date) : getNights(group.stay.start_date, group.stay.end_date);
					var hotel = client.products.hotel;

					//vm.hotel_name = vm.hotel_name || hotel.name;

					vm.starting_currency = hotel.monnaieDepart;
					var cal = CalculationService;

					cal.init(function () {
						return {
							product: client.products,
							occupant: getClient
						}
					});


					var client_info = getClient(client._id);
					var total = (hotel.purchase_price_default || 0);
					vm.total_group += (hotel.purchase_price_default);
					table.rows.push({
						index: (clientIndex + 1),
						nights: nights,
						voucher: client.products.hotel.voucher,
						username: client_info.username,
						indication: (hotel.indication || ''),
						purchase_price: total
					});
					angular.forEach(hotel.occupants, function (occupant, id) {
						var occupantIndex = 0;
						vm.statictics.occupants++;
						switch (occupant.occupant_type) {
							case ('Adulte'):
								vm.statictics.adults++;
								break;
							case ('Enfant'):
								vm.statictics.kids++;
								break;
							case ('Bébé'):
								vm.statictics.babies++;
								break;
						}
						table.rows.push({
							index: 'Ch ' + (occupant.room_number || ''),
							nights: nights,
							username: getClient(id).username,
							occupant_type: occupant.occupant_type,
							room_type: occupant.room_type,
							indication: (occupant.indication || ''),
							supplement_type: occupant.supplement_type,
							purchase_price: (cal.hotelPriceByOccupant(id) * nights)
						});
					});
				}
			});

			return table;
		}



		function print(agency_logo, agency_info, trip_name, trip_date, group_number, group, clients) {
			vm.clients = clients;
			try {
				var doc = new jsPDF();

				// Agency Header
				doc.setFont("times");
				// Agency logo
				if (agency_logo) doc.addImage(agency_logo, 'JPEG', 5, 5, 35, 35);

				// Header Text
				doc.setFontSize(16)
				doc.text(45, 13, (agency_info.name || ''));
				doc.setFontSize(10)
				doc.text(45, 20, 'Tél : ' + (agency_info.phone || ''));
				doc.text(45, 25, 'Fax : ' + (agency_info.fax || ''));
				doc.text(45, 30, 'Adresse : ' + (agency_info.address || ''));

				doc.line(120, 12, 120, 32);

				// doc.text(130, 15, 'Agent : ' + $rootScope.current_user.email);
				// agency legal information

				doc.text(130, 15, 'RC : ' + (agency_info.rc || ''));
				doc.text(130, 20, 'AI : ' + (agency_info.ai || ''));
				doc.text(130, 25, 'NIF / NIS : ' + (agency_info.nif_nis || ''));
				doc.text(130, 30, (agency_info.bank || ''));


				// Facture
				doc.setFontSize(13)
				doc.line(10, 43, 10, 53);
				doc.line(10, 43, 200, 43);
				doc.text(105, 49, 'FACTURE ' + group.hotel.name.toUpperCase() + ' ARRIVEE ' + group.stay.start_date.toLocaleDateString() + ' Au ' + group.stay.end_date.toLocaleDateString(), null, null, 'center')
				doc.line(200, 43, 200, 53);
				doc.line(10, 53, 200, 53);


				// Occupants Details Table Content
				var table = getOccupantsTable(group);

				doc.setFontType("normal");

				doc.setFontSize(13);
				var columns = table.columns;
				var rows = table.rows;




				doc.autoTable([{
					dataKey: "title1"
				}, {
					dataKey: "value1"
				}, {
					dataKey: "title2"
				}, {
					dataKey: "value2"
				}], [{
					title1: "Nombre de Personnes",
					value1: vm.statictics.occupants,
					title2: "Nombre d'Adultes",
					value2: vm.statictics.adults
				}, {
					title1: "Nombre d'Enfants",
					value1: vm.statictics.kids,
					title2: "Nombre de Bébés",
					value2: vm.statictics.babies
				}], {
					showHeader: 'never',
					styles: {
						fillColor: false,
						textColor: 0,
						lineColor: 0,
						font: "times"
					},
					headerStyles: {
						textColor: 0,
						lineColor: 0
					},
					theme: 'grid',
					startY: 65,
					margin: {
						right: 35,
						left: 35
					}
				});

				doc.autoTable([{
					dataKey: "title"
				}, {
					dataKey: "currency"
				}, {
					dataKey: "value"
				}], [{
					title: "Total Vente",
					currency: group.hotel.monnaieDepart,
					value: vm.total_group
				}], {
					startY: doc.autoTable.previous.finalY + 5,
					showHeader: 'never',
					styles: {
						fillColor: false,
						textColor: 0,
						lineColor: 0,
						font: "times"
					},
					headerStyles: {
						textColor: 0,
						lineColor: 0
					},
					theme: 'grid',
					margin: {
						right: 35,
						left: 35
					}
				});

				doc.setFontSize(12);
				doc.setFontType("bold");
				doc.text(5, doc.autoTable.previous.finalY + 7, 'Nombre de gratuités : ');
				doc.text(5, doc.autoTable.previous.finalY + 12, 'Montant gratuités     : ');
				doc.setFontType("normal");
				doc.text(47, doc.autoTable.previous.finalY + 7, (group.hotel.nb_freebies || "0") + "");
				doc.text(47, doc.autoTable.previous.finalY + 12, (group.hotel.freebies_amount || "0") + "");

				doc.setFontSize(13);
				doc.autoTable(columns, rows, {
					startY: doc.autoTable.previous.finalY + 15,
					styles: {
						fillColor: false,
						textColor: 0,
						lineColor: 0,
						font: "times"
					},
					headerStyles: {
						textColor: 0,
						lineColor: 0
					},
					overflow: 'linebreak',
					tableWidth: 200,
					theme: 'grid',
					margin: {
						left: 5
					}
				});

				// doc.autoPrint()
				doc.save('FACTURE ' + group.hotel.name.toUpperCase() + ' ARRIVEE ' + group.stay.start_date.toLocaleDateString() + ' Au ' + group.stay.end_date.toLocaleDateString() + '.pdf');
			} catch (err) {
				console.log(err);

				toastr.warning('Veuiller Remplir les informations restantes!', 'Attention');
			}
		}
	}
})();