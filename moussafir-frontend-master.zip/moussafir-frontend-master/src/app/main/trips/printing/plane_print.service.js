(function () {
	'use strict';

	angular
		.module('main.trips')
		.factory('PlanePrintService', PlanePrintService);

	function PlanePrintService($rootScope, toastr) {
		var vm = this;

		return {
			print: print
		}

		function getClient(id) {
			return vm.clients.find(function (elem) {
				return elem._id === id
			});
		}

		function getOccupantsTable(group) {

			var table = {
				columns: [{
					title: "N°",
					dataKey: "index"
				}, {
					title: "Nom Complet",
					dataKey: "username"
				}, {
					title: "Numéro Téléphone",
					dataKey: "phone_number"
				}, {
					title: "N° billet d'avion",
					dataKey: "ticket_number"
				}, {
					title: "Indication",
					dataKey: 'indication'
				}],
				rows: []
			};

			var index = 0;

			angular.forEach(group.clients, function (client) {
				if (client.products) {
					vm.plane_ticket = client.products.plane_ticket;
					var client_info = getClient(client._id);

					table.rows.push({
						index: 'Client',
						username: client_info.username,
						phone_number: (client_info.phone_numbers ? client_info.phone_numbers[0] : ""),
						indication: (vm.plane_ticket.indication || '')
					});
					angular.forEach(vm.plane_ticket.occupants, function (occupant, id) {
						var occupant_info = getClient(id);
						table.rows.push({
							index: ++index,
							username: occupant_info.username,
							seat_number: occupant.seat_number,
							departure_place: occupant.departure_place,
							ticket_number: occupant.number,
							phone_number: (occupant_info.phone_numbers ? occupant_info.phone_numbers[0] : ""),
							indication: (occupant.indication || ''),
						});
					});
					table.rows.push({});
				}
			});

			table.rows.pop();

			table.rows.sort(function (a, b) {
				var nameA = a.username.toUpperCase();
				var nameB = b.username.toUpperCase();
				if (nameA < nameB) return -1;
				if (nameA > nameB) return 1;
				return 0;
			});

			return table;
		}



		function print(agency_logo, agency_info, trip_name, trip_date, group_number, group, clients) {
			vm.clients = clients;
			try {
				var doc = new jsPDF();

				// Agency Header
				doc.setFont("times");
				// Agency logo
				if (agency_logo) doc.addImage(agency_logo, 'JPEG', 5, 5, 35, 35);

				// Header Text
				doc.setFontSize(16)
				doc.text(45, 13, (agency_info.name || ''));
				doc.setFontSize(12)
				doc.text(200, 13, 'Agent : ' + $rootScope.current_user.email, null, null, 'right');


				doc.text(45, 20, 'Tél : ' + (agency_info.phone || ''));
				doc.text(45, 25, 'Fax : ' + (agency_info.fax || ''));
				doc.text(45, 30, 'Adresse : ' + (agency_info.address || ''));


				// Facture
				doc.setFontSize(13);
				doc.line(10, 43, 10, 53);
				doc.line(10, 43, 200, 43);
				doc.text(105, 49, ('Liste des billet d\'avion ' + trip_name + ' groupe ' + (parseInt(group_number) + 1) + ' ARRIVEE ' + group.stay.start_date.toLocaleDateString() + ' Au ' + group.stay.end_date.toLocaleDateString()).toUpperCase(), null, null, 'center')
				doc.line(200, 43, 200, 53);
				doc.line(10, 53, 200, 53);

				// Occupants Details Table Content
				var table = getOccupantsTable(group);


				doc.setFontSize(13);
				doc.setFontType("normal");
				doc.text(200, 60, 'Guide : ' + (group.guide_name || ''), null, null, 'right');

				doc.setFontSize(13);
				var columns = table.columns;
				var rows = table.rows;

				var tickets_columns = [{
					title: "",
					dataKey: "sideTitle"
				}, {
					title: "Date départ",
					dataKey: "departure_date"
				}, {
					title: "Heure Départ",
					dataKey: "departure_time"
				}, {
					title: "Date d'arrivée",
					dataKey: "arrival_date"
				}, {
					title: "Heure d'arrivée",
					dataKey: "arrival_time"
				}];

				doc.setFontType("bold");
				doc.text(5, 60, "Détail de Vol:");
				doc.setFontType("normal");

				tickets_columns.push({
					title: 'Aeroport Départ',
					dataKey: 'departure_airport'
				}, {
					title: 'Aeroport d\'Arrivée',
					dataKey: 'arrival_airport'
				});

				var tickets_rows = [{
					sideTitle: 'Aller',
					departure_date: new Date(vm.plane_ticket.departure_date_from).toLocaleDateString(),
					departure_time: new Date(vm.plane_ticket.departure_time_from).toLocaleTimeString(),
					arrival_date: new Date(vm.plane_ticket.arrival_date_from).toLocaleDateString(),
					arrival_time: new Date(vm.plane_ticket.arrival_time_from).toLocaleTimeString(),
					departure_airport: vm.plane_ticket.departure_airport_from,
					arrival_airport: vm.plane_ticket.arrival_airport_from
				}];
				if (vm.plane_ticket.ticket_type === "Aller-Retour") {
					tickets_rows.push({
						sideTitle: 'Retour',
						departure_date: new Date(vm.plane_ticket.departure_date_to).toLocaleDateString(),
						departure_time: new Date(vm.plane_ticket.departure_time_to).toLocaleTimeString(),
						arrival_date: new Date(vm.plane_ticket.arrival_date_to).toLocaleDateString(),
						arrival_time: new Date(vm.plane_ticket.arrival_time_to).toLocaleTimeString(),
						departure_airport: vm.plane_ticket.departure_airport_to,
						arrival_airport: vm.plane_ticket.arrival_airport_to
					})
				}
				doc.autoTable(tickets_columns, tickets_rows, {
					styles: {
						fillColor: false,
						textColor: 0,
						lineColor: 0,
						font: "times"
					},
					headerStyles: {
						textColor: 0,
						lineColor: 0
					},
					tableWidth: 200,
					theme: 'grid',
					startY: 65,
					margin: {
						left: 5
					}
				});

				doc.autoTable(columns, rows, {
					styles: {
						fillColor: false,
						textColor: 0,
						lineColor: 0,
						font: "times"
					},
					headerStyles: {
						textColor: 0,
						lineColor: 0
					},
					tableWidth: 200,
					theme: 'grid',
					startY: doc.autoTable.previous.finalY + 5,
					margin: {
						left: 5
					}
				});

				// doc.autoPrint()
				doc.save(('Liste des billet d\'avion ' + trip_name + ' groupe ' + (parseInt(group_number) + 1) + ' ARRIVEE ' + group.stay.start_date.toLocaleDateString() + ' Au ' + group.stay.end_date.toLocaleDateString()) + '.pdf');
			} catch (err) {
				console.log(err);

				toastr.warning('Veuiller Remplir les informations restantes!', 'Attention');
			}
		}
	}
})();