(function () {
	'use strict';

	angular
		.module('main.trips')
		.factory('BusPrintService', BusPrintService);

	function BusPrintService($rootScope, toastr) {
		var vm = this;

		return {
			print: print
		}

		function getClient(id) {
			return vm.clients.find(function (elem) {
				return elem._id === id
			});
		}

		function getOccupantsTable(group) {

			var table = {
				columns: [{
					title: "N°",
					dataKey: "index"
				}, {
					title: "Nom Complet",
					dataKey: "username"
				}, {
					title: "Numéro Téléphone",
					dataKey: "phone_number"
				}, {
					title: "N° Siège",
					dataKey: "seat_number"
				}, {
					title: "Départ",
					dataKey: "departure_place"
				}, {
					title: "Indication",
					dataKey: 'indication'
				}],
				rows: []
			};

			var index = 0;

			vm.statictics = {
				occupants: 0,
				total_seats: 0,
				total_used_seats: 0
			};
			vm.statictics.total_seats = group.road_transport.nb_places || 0;
			var occupantIndex = 0;
			angular.forEach(group.clients, function (client, index) {
				if (client.products) {
					var road_transport = client.products.road_transport;
					vm.driver_name = group.road_transport.driver_name || road_transport.driver_name || '';
					var client_info = getClient(client._id);

					table.rows.push({
						index: 'Client ' + (index + 1),
						username: client_info.username,
						phone_number: (client_info.phone_numbers ? client_info.phone_numbers[0] : ""),
						indication: (road_transport.indication || '')
					});
					angular.forEach(road_transport.occupants, function (occupant, id) {
						vm.statictics.occupants++;
						if (occupant.seat_number) vm.statictics.total_used_seats++;
						var occupant_info = getClient(id);
						table.rows.push({
							index: ++occupantIndex,
							username: occupant_info.username,
							seat_number: occupant.seat_number,
							departure_place: occupant.departure_place,
							phone_number: (occupant_info.phone_numbers ? occupant_info.phone_numbers[0] : ""),
							indication: (occupant.indication || ''),
						});
					});
				}
			});

			return table;
		}



		function print(agency_logo, agency_info, trip_name, trip_date, group_number, group, clients) {
			vm.clients = clients;
			try {
				var doc = new jsPDF();

				// Agency Header
				doc.setFont("times");
				// Agency logo
				if (agency_logo) doc.addImage(agency_logo, 'JPEG', 5, 5, 35, 35);

				// Header Text
				doc.setFontSize(16)
				doc.text(45, 13, (agency_info.name || ''));
				doc.setFontSize(12)
				doc.text(200, 13, 'Agent : ' + $rootScope.current_user.email, null, null, 'right');


				doc.text(45, 20, 'Tél : ' + (agency_info.phone || ''));
				doc.text(45, 25, 'Fax : ' + (agency_info.fax || ''));
				doc.text(45, 30, 'Adresse : ' + (agency_info.address || ''));


				// Facture
				doc.setFontSize(13);
				doc.line(5, 43, 5, 53);
				doc.line(5, 43, 205, 43);
				doc.text(105, 49, ('Liste de Bus voyage ' + trip_name + ' groupe ' + (parseInt(group_number) + 1) + ' ARRIVEE ' + group.stay.start_date.toLocaleDateString() + ' Au ' + group.stay.end_date.toLocaleDateString()).toUpperCase(), null, null, 'center')
				doc.line(205, 43, 205, 53);
				doc.line(5, 53, 205, 53);

				// Occupants Details Table Content
				var table = getOccupantsTable(group);


				doc.setFontSize(12);
				doc.setFontType("bold");
				doc.text(5, 60, 'Nom du chauffeur : ');
				doc.setFontType("normal");
				doc.text(43, 60, vm.driver_name);
				doc.text(200, 60, 'Guide : ' + (group.guide_name || ''), null, null, 'right');

				doc.setFontSize(13);
				var columns = table.columns;
				var rows = table.rows;

				doc.autoTable([{
					dataKey: "title"
				}, {
					dataKey: "value"
				}], [{
					title: "Nombre de Personnes",
					value: vm.statictics.occupants
				}, {
					title: "Nombre de places vide",
					value: (vm.statictics.total_seats - vm.statictics.total_used_seats)
				}], {
					showHeader: 'never',
					startY: 65,
					styles: {
						fillColor: false,
						textColor: 0,
						lineColor: 0,
						font: "times"
					},
					headerStyles: {
						textColor: 0,
						lineColor: 0
					},
					theme: 'grid',
					margin: {
						right: 35,
						left: 35
					}
				});

				doc.autoTable(columns, rows, {
					styles: {
						fillColor: false,
						textColor: 0,
						lineColor: 0,
						font: "times"
					},
					headerStyles: {
						textColor: 0,
						lineColor: 0
					},
					tableWidth: 200,
					theme: 'grid',
					startY: doc.autoTable.previous.finalY + 5,
					margin: {
						left: 5
					}
				});

				// doc.autoPrint()
				doc.save('Bus Voyage ' + trip_name + ' g_' + (parseInt(group_number) + 1) + '.pdf');
			} catch (err) {
				console.log(err);

				toastr.warning('Veuiller Remplir les informations restantes!', 'Attention');
			}
		}
	}
})();