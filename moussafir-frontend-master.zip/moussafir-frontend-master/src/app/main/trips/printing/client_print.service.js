(function () {
	'use strict';

	angular
		.module('main.trips')
		.factory('ClientPrintService', ClientPrintService);

	function ClientPrintService($rootScope, $state, toastr, CalculationService) {
		var vm = this;

		return {
			print: print
		}

		function contains(string, selectedProducts) {
			for (var i = 0; i < selectedProducts.length; i++) {
				if (selectedProducts[i] === string) {
					return true;
				}
			}
			return false;
		}

		function dateNow() {
			var d = new Date(),
				h = (d.getHours() < 10 ? '0' : '') + d.getHours(),
				m = (d.getMinutes() < 10 ? '0' : '') + d.getMinutes();
			return {
				time: h + 'h' + m,
				date: d.toLocaleDateString()
			}
		}

		function getClient(id) {
			return vm.clients.find(function (elem) {
				return elem._id === id
			});
		}

		function getNights(from, to) {
			if (!from || !to) return 0;
			return moment.duration(moment(to).diff(moment(from))).asDays();
		}

		function getOccupantTable(client, selectedProducts) {
			var client_info = getClient(client._id);

			var table = {
				columns: [{
					title: "N°",
					dataKey: "index"
				}, {
					title: "Nté",
					dataKey: "nights"
				}, {
					title: "Nom Complet",
					dataKey: "username"
				}, {
					title: "Personne",
					dataKey: "occupant_type"
				}, {
					title: "Chambre",
					dataKey: "room_type"
				}, {
					title: "Arrangement",
					dataKey: "supplement_type"
				}, {
					title: "N° Siège",
					dataKey: "seat_number"
				}, {
					title: "Départ",
					dataKey: "departure_place"
				}, {
					title: "N° billet d'avion",
					dataKey: "plane_ticket_number"
				}],
				rows: []
			};

			var index = 0;

			if (client.products) {
				var nights = getNights(client.products.stay.start_date, client.products.stay.end_date)


				if (contains('travel_insurence', selectedProducts)) vm.product = client.products.travel_insurence;
				if (contains('consulat', selectedProducts)) vm.product = client.products.visa.consulat;
				if (contains('rendez_vous', selectedProducts)) vm.product = client.products.visa.rendez_vous;
				if (contains('other', selectedProducts)) vm.product = client.products.other;

				if (contains('ranting', selectedProducts)) vm.product = client.products.ranting;

				if (contains('hotel', selectedProducts)) {
					vm.product = client.products.hotel;
					//vm.hotel_name = vm.hotel_name || vm.product.name;
				}

				if (contains('road_transport', selectedProducts)) {
					var road_transport = client.products.road_transport;
					vm.driver_name = vm.driver_name || road_transport.driver_name;
				}

				angular.forEach(vm.product.occupants, function (occupant, id) {
					table.rows.push({
						index: ++index,
						nights: nights,
						username: getClient(id).username,
						occupant_type: occupant.occupant_type,
						room_type: occupant.room_type,
						supplement_type: occupant.supplement_type,
						seat_number: road_transport ? road_transport.occupants[id].seat_number : '',
						departure_place: road_transport ? road_transport.occupants[id].departure_place : '',
						plane_ticket_number: (client.products.plane_ticket.occupants ? client.products.plane_ticket.occupants[id].number : '')
					});
				});
			}

			return table;
		}

		function print(devis, dailyCount, totalCount, agency_logo, agency_info, trip_name, trip_date, selectedProducts, groupNumber, group, client, clients, callback) {
			vm.clients = clients;
			try {
				var doc = new jsPDF();
				var table = getOccupantTable(client, selectedProducts);
				doc.setFont("times");

				// Agency logo
				if (agency_logo) doc.addImage(agency_logo, 'JPEG', 5, 5, 35, 35);

				// Header Text
				doc.setFontSize(16)
				doc.text(45, 13, (agency_info.name || ''));
				doc.setFontSize(12)
				doc.text(200, 13, 'Agent : ' + $rootScope.current_user.email, null, null, 'right');
				var now = dateNow();
				doc.setFontSize(13)
				doc.text(200, 20, now.date, null, null, 'right');
				doc.text(200, 27, now.time, null, null, 'right');
				doc.setFontSize(12)

				doc.text(45, 20, 'Tél : ' + (agency_info.phone || ''));
				doc.text(45, 25, 'Fax : ' + (agency_info.fax || ''));
				doc.text(45, 30, 'Adresse : ' + (agency_info.address || ''));

				// Document Title
				doc.setFontSize(25)
				doc.setFontType("bold");
				doc.text(105, 50, (devis ? 'Devis' : 'Reçu de Payment') + ' N°g ' + dailyCount, null, null, 'center');

				// Product Price
				doc.setFontSize(13);
				doc.setFontType("normal");
				doc.line(0, 58, 210, 58);
				doc.text(5, 65, 'Reçu la somme de : ' + (client.products.paid_amount || 0) + " DZD");
				doc.text(105, 65, 'Total : ' + (client.products.total || 0), null, null, 'center');
				doc.text(200, 65, 'Reste : ' + (((client.products.total || 0) - (client.products.paid_amount || 0))), null, null, 'right');
				doc.line(0, 68, 210, 68);

				// Product Information
				doc.text(5, 80, 'Nom du voyage : ' + trip_name);
				doc.text(5, 87, 'A partir de : ' + new Date(client.products.stay.start_date).toLocaleDateString());
				doc.text(200, 87, 'Jusqu\'au : ' + new Date(client.products.stay.end_date).toLocaleDateString(), null, null, 'right');
				doc.text(5, 94, 'Destination : ' + client.products.destination);
				doc.text(200, 94, 'Groupe : ' + (parseInt(groupNumber) + 1), null, null, 'right');


				// Client name
				var client_info = getClient(client._id);
				doc.setFontType("bold");
				doc.text(5, 110, 'Client : ');
				doc.setFontType("normal");
				doc.text(25, 110, client_info.username);

				// Occupants names
				doc.setFontType("bold");
				doc.text(5, 120, 'Nom des occupants : ');
				doc.setFontType("normal");
				doc.line(8, 125, 200, 125);

				var occupant_number = 1;
				angular.forEach(vm.product.occupants, function (occupant, id) {
					if (occupant_number % 2 !== 0) {
						doc.text(15, 125 + ((parseInt(occupant_number / 2) + 1) * 10), occupant_number + '/ ' + getClient(id).username);
					} else {
						doc.text(190, 125 + (parseInt(occupant_number / 2) * 10), occupant_number + '/ ' + getClient(id).username, null, null, 'right');
					}
					occupant_number++;
				});


				var occupant_margin = 125 + (parseInt(occupant_number / 2) * 10);
				doc.line(8, (occupant_margin + 5), 8, 125);
				doc.line(200, (occupant_margin + 5), 200, 125);
				doc.line(8, (occupant_margin + 5), 200, (occupant_margin + 5));


				// Occupants Details Table Header
				doc.setFontSize(20)
				doc.setFontType("bold");
				doc.text(105, occupant_margin + 13, 'Détail d\'achat N°g ' + dailyCount, null, null, 'center');
				doc.setFontSize(13)
				doc.setFontType("normal");
				doc.text(105, occupant_margin + 20, 'Liste des Personnes', null, null, 'center');

				if (contains('hotel', selectedProducts)) {
					doc.setFontSize(12);
					doc.text(205, occupant_margin + 27, 'Nom d\'Hôtel : ' + group.hotel.name, null, null, 'right');
				}

				// first page Footer
				doc.setFontSize(11);
				doc.setFontType("bold");
				doc.text(5, occupant_margin + 27, 'Numéro Téléphone: ');
				doc.setFontType("normal");
				doc.text(43, occupant_margin + 27, (client_info.phone_numbers ? client_info.phone_numbers[0] : ''));


				// Occupants Details Table Content
				var columns = table.columns;
				var rows = table.rows;

				var tickets_columns = [{
					title: "",
					dataKey: "sideTitle"
				}, {
					title: "Date départ",
					dataKey: "departure_date"
				}, {
					title: "Heure Départ",
					dataKey: "departure_time"
				}, {
					title: "Date d'arrivée",
					dataKey: "arrival_date"
				}, {
					title: "Heure d'arrivée",
					dataKey: "arrival_time"
				}];

				var previous = false;
				// Plane ticket details
				if (contains('plane_ticket', selectedProducts)) {
					doc.setFontType("bold");
					doc.text(5, occupant_margin + 35, "Détail de Vol:");
					doc.setFontType("normal");

					tickets_columns.push({
						title: 'Aeroport Départ',
						dataKey: 'departure_airport'
					}, {
						title: 'Aeroport d\'Arrivée',
						dataKey: 'arrival_airport'
					});

					var tickets_rows = [{
						sideTitle: 'Aller',
						departure_date: new Date(client.products.plane_ticket.departure_date_from).toLocaleDateString(),
						departure_time: new Date(client.products.plane_ticket.departure_time_from).toLocaleTimeString(),
						arrival_date: new Date(client.products.plane_ticket.arrival_date_from).toLocaleDateString(),
						arrival_time: new Date(client.products.plane_ticket.arrival_time_from).toLocaleTimeString(),
						departure_airport: client.products.plane_ticket.departure_airport_from,
						arrival_airport: client.products.plane_ticket.arrival_airport_from
					}];
					if (client.products.plane_ticket.ticket_type === "Aller-Retour") {
						tickets_rows.push({
							sideTitle: 'Retour',
							departure_date: new Date(client.products.plane_ticket.departure_date_to).toLocaleDateString(),
							departure_time: new Date(client.products.plane_ticket.departure_time_to).toLocaleTimeString(),
							arrival_date: new Date(client.products.plane_ticket.arrival_date_to).toLocaleDateString(),
							arrival_time: new Date(client.products.plane_ticket.arrival_time_to).toLocaleTimeString(),
							departure_airport: client.products.plane_ticket.departure_airport_to,
							arrival_airport: client.products.plane_ticket.arrival_airport_to
						})
					}
					doc.autoTable(tickets_columns, tickets_rows, {
						styles: {
							fillColor: false,
							textColor: 0,
							lineColor: 0,
							font: "times"
						},
						headerStyles: {
							textColor: 0,
							lineColor: 0
						},
						tableWidth: 200,
						theme: 'grid',
						startY: occupant_margin + 37,
						margin: {
							left: 5
						}
					});

					previous = true;
				} else {
					// Ship ticket details
					if (contains("ship_ticket", selectedProducts)) {
						doc.setFontType("bold");
						doc.text(5, occupant_margin + 35, "Détail du transport maritime :");
						doc.setFontType("normal");


						tickets_columns.push({
							title: 'Port Départ',
							dataKey: 'departure_airport'
						}, {
							title: 'Port d\'Arrivée',
							dataKey: 'arrival_airport'
						});

						var tickets_rows = [{
							sideTitle: 'Aller',
							departure_date: new Date(client.products.ship_ticket.departure_date_from).toLocaleDateString(),
							departure_time: new Date(client.products.ship_ticket.departure_time_from).toLocaleTimeString(),
							arrival_date: new Date(client.products.ship_ticket.arrival_date_from).toLocaleDateString(),
							arrival_time: new Date(client.products.ship_ticket.arrival_time_from).toLocaleTimeString(),
							departure_airport: client.products.ship_ticket.departure_ship_from,
							arrival_airport: client.products.ship_ticket.arrival_ship_from
						}]

						doc.autoTable(tickets_columns, tickets_rows, {
							styles: {
								fillColor: false,
								textColor: 0,
								lineColor: 0,
								font: "times"
							},
							headerStyles: {
								textColor: 0,
								lineColor: 0
							},
							tableWidth: 200,
							theme: 'grid',
							startY: occupant_margin + 37,
							margin: {
								left: 5
							}
						});

						previous = true;
					}
				}

				if (contains("other", selectedProducts) && (selectedProducts.length === 1)) {
					columns = rows = [];
					rows.push(client.products.other);
					doc.autoTable([{
						title: 'Produit',
						dataKey: 'name'
					}, {
						title: 'Titre',
						dataKey: 'title'
					}, {
						title: 'Total',
						dataKey: 'total'
					}, {
						title: 'Indication',
						dataKey: 'indication'
					}], rows, {
						styles: {
							fillColor: false,
							textColor: 0,
							lineColor: 0,
							font: "times"
						},
						headerStyles: {
							textColor: 0,
							lineColor: 0
						},
						tableWidth: 200,
						theme: 'grid',
						startY: previous ? doc.autoTable.previous.finalY + 5 : occupant_margin + 30,
						margin: {
							left: 5
						}
					});

					doc.setFontType("bold");
					doc.text(5, doc.autoTable.previous.finalY + 7, 'Indication : ');
					doc.setFontType("normal");
					doc.text(30, doc.autoTable.previous.finalY + 7, client.products.other.indication || "");
				} else {
					doc.autoTable(columns, rows, {
						styles: {
							fillColor: false,
							textColor: 0,
							lineColor: 0,
							font: "times"
						},
						headerStyles: {
							textColor: 0,
							lineColor: 0
						},
						tableWidth: 200,
						theme: 'grid',
						startY: previous ? doc.autoTable.previous.finalY + 5 : occupant_margin + 30,
						margin: {
							left: 5
						}
					});
				}

				if (contains("hotel", selectedProducts)) {
					doc.setFontType("bold");
					doc.text(5, doc.autoTable.previous.finalY + 7, 'Bon Voucher : ');
					doc.text(5, doc.autoTable.previous.finalY + 12, 'Indication : ');
					doc.setFontType("normal");
					doc.text(35, doc.autoTable.previous.finalY + 7, vm.product.voucher || "");
					doc.text(30, doc.autoTable.previous.finalY + 12, vm.product.indication || "");
				}


				var codebar = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAFKCAYAAADBkCHRAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAABt0wAAbdMBfrSbrwAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAATdEVYdFRpdGxlAFJTVlAgQmFyIENvZGUA3jonAAAKQUlEQVR4nO3ZTagdZx3H8f/RYuuiUt8wupCIQrtRIhQsurGgKC5EQTHQhS8odKngot0VFyK4sAsXBd9aoRJRNFSQiAWjqAQpNSiUFlq8iC2tr6FFm9rK30VOyGTunDNz7v1poHw+cCBz5plnZp4z59wvZNXdBQBAzkuu9AUAALzYCCwAgLCrrvQFrFarV1fVRzfsPtPdZwdjr62qW9abj3b3/VvmfWlVfWa9+cfu/vEhrvHGqrrxAIf+tLsfG831yaq6uqr+0d3fHe37YFW9YcG8D3T3A6NjP1xVr1tw7Pe6+2+D4xav6dhqtXprVb1rw+4fdPefB2Ovr6qb15u/6O6Hlp5n4rwfqarXTOz6XXf/ejR2uKZf6+7/bJn3PVX1loldyefnvu5+YsvY4ZpOPT+frgvf27929/cPcU3vq6o3Tex6obu/Php7c1Vdv9480d3ntsz7jqp6+3pz/Ay8rKo+td6cXdPBve7ime6+d2bej1XVK6vque7+1mjfm6vqvVPHdfddM/MO1/Se7n528VVfPs/wO/lId//sIPOs57p4r//q7m/PjN30G7JvTVer1Qeq6o3rzW92978PeH3XVdXxDbvHz8/Lq+rj680/dPdPZua+df3PJ7r7vpmx236Xj1XVTROHza7pzDmPVtX715vjv3XDe93FvntdrVbvrKq3LTh235quVqtbquraJefZZtv3amTfmo5+l+/t7mcG+7b1w2V/666I7r6ir6o6VlW94XXbaOzRwb4TM/NeMxh76pDXeMeWa9z2Oj4x17n1vocn9p1eOO8dE8eeWXjssYOu6cQ5P7vlPDeNxn5isO/WQ34eZzec886ZNb1mZt4TG+ZNPj/v3mFNp56f8+t9Zw95TSc33Ov5ibF3D/bfMDPvl7Y8A9ftsqaDe93ltbdg3ofXY89N7Du+ae4d1/TIIT6b4Xfy7kN+zhfv9ckFYzf9huxb06o6Ndh/3SGu74Ytn+X4+Tky2HdywdwXx55eMHbb7/JtG65vdk1nzvmhwVzjv3VHNpxz7rXvXqvqzoXH7lvTqtpbep6Ze934vZpb07r8d/noaN+2fji2yzX+L17+ixAAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAICwq670BVTV41X1uQ37fjna/vtg7CMz8z4/GLt3oCu75FRVnTvAcQ9OvHd7VV1dF+5l7KtVdXLBvGcm3vtKVb1+wbGPj7Z3WdOxn9fmz25vtP2bwdhf7XiesS9X1Wsn3v/txHvDNX1+Zt57anpt9xZf2bTh8/PozNjhmk49P5+vC9/bvxzymr5RVacn3n9h4r3vVNXZ9b+fmpn3R1X15Prfe6N9z9Zu38mL97qLpxeM+WJVvaqqnpvY92BtfqbnDNd0yXVsMvxOPnSIeaou3es/F4zd9BsydS931YXnuurC53pQT9Xy35CnB2MfWzD3xbF/WjB22+/y/VV1fuL9JWu6ze/r0jWO/9YN73UXU/f6w1r2fZta0y9U1SsWnmebpd+rqTUd/i6PP59t/TD+W/d/t+ruK30NAAAvKv6LEAAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGH/BecbCaIn2VHEAAAAAElFTkSuQmCC';


				doc.text(5, doc.autoTable.previous.finalY + 20, 'N° d\'impression : ' + totalCount);
				doc.addImage(codebar, 'JPEG', 2, doc.autoTable.previous.finalY + 21, 60, 15);


				// first page Footer
				doc.setFontSize(12);
				doc.text(5, doc.autoTable.previous.finalY + 50, agency_info.footer);

				// doc.autoPrint()
				doc.save((devis ? 'Devis ' : 'Reçu ') + dailyCount + ' g' + (parseInt(groupNumber) + 1) + ' ' + now.date + '.pdf');
				if (typeof callback === 'function') callback();
			} catch (err) {
				console.log(err);

				toastr.warning('Veuiller Remplir les informations restantes!', 'Attention');
			}
		}
	}
})();