(function () {
	'use strict';

	angular
		.module('main.trips', [])
		.config(config);

	function config($stateProvider) {
		$stateProvider
			.state('trips', {
				parent: 'main',
				abstract: true,
				title: 'Voyage organisé',
				translate: "trips.main",
				sidebarMeta: {
					icon: 'ion-person',
					order: 70,
				},
				loginRequired: true
			})
			.state('trips_dashboard', {
				parent: 'main',
				url: '/trips/dashboard',
				templateUrl: 'app/main/trips/dashboard/dashboard.html',
				title: 'Balance',
				translate: "balance.main",
				controller: "TripsDashboardController",
				controllerAs: "dashVm",
				sidebarMeta: {
					order: 72,
					roles: ['admin', 'super-admin']
				},
				loginRequired: true,
				adminRequired: true
			})// ybanou f sidebar
			.state('trips_with_rest', {
				parent: 'main',
				url: '/trips/with-rest',
				templateUrl: 'app/main/trips/with-rest/with-rest.html',
				title: 'Client Avec Reste',
				translate: "trips.rest",
				controller: "TripsWithRestController",
				controllerAs: "twrVm",
				sidebarMeta: {
					order: 73
				},
				loginRequired: true
			})
			.state('trips_list', {
				parent: 'main',
				url: '/trips/list',
				templateUrl: 'app/main/trips/list/trips.html',
				title: 'Liste des Voyages',
				translate: "trips.list",
				controller: "TripsController as tripsVm",
				sidebarMeta: {
					order: 75
				},
				loginRequired: true
			})
			.state('add_trip', {
				parent: 'main',
				url: '/trips/add',
				templateUrl: 'app/main/trips/trip/trip.html',
				title: 'Ajouter Voyage',
				translate: "trips.add",
				controller: "TripController",
				controllerAs: "tripVm",
				sidebarMeta: {
					order: 80
				},
				loginRequired: true
			})
			.state('edit_trip', {
				parent: 'main',
				url: '/trips/edit/:id',
				templateUrl: 'app/main/trips/trip/trip.html',
				title: 'Modifier Voyage',
				translate: "trips.edit",
				controller: "TripController",
				controllerAs: "tripVm",
				loginRequired: true
			});
	}
})();