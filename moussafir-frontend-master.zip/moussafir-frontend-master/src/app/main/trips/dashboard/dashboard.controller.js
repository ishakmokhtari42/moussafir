(function () {
	'use strict';

	angular
		.module("main.trips")
		.controller("TripsDashboardController", TripsDashboardController);

	function TripsDashboardController(TripService, UserService, toastr, $window, $state, ErrorToast, dialogs) {
		var vm = this;

		vm.trips = [];
		vm.filtered_trips = [];
		vm.users = [];
		vm.selectedUsers = [];

		vm.productTypes = [{
				title: "Réservation d’hôtel",
				name: 'hotel'
			},
			{
				title: "Billet d’avion",
				name: 'plane_ticket'
			},
			{
				title: "Transport routier",
				name: 'road_transport'
			},
			{
				title: "Location",
				name: 'ranting'
			},
			{
				title: "Assurence de voyage",
				name: 'travel_insurence'
			},
			{
				title: "Vente simple",
				name: 'other'
			}
		];

		TripService.query(function (data) {
			vm.trips = data;
			vm.filtered_trips = vm.trips;
			calculate();
		}, function (error) {
			ErrorToast(error);
		});

		UserService.query({
			'$select': ['email', 'role']
		}, function (data) {
			vm.users = data;
			for (var i = 0; i < vm.users.length; i++) {
				if (vm.users[i].role === "super-admin") {
					vm.users.splice(i, 1);
					break;
				}
			}
		}, function (error) {
			ErrorToast(error);
		});

		vm.filter = filter;
		vm.deleteTrip = deleteTrip;
		vm.getDate = getDate;
		vm.getProductType = getProductType;

		function getProductType(type) {
			return vm.productTypes.find(function (productType) {
				return type === productType.name;
			});
		}

		function getDate(stringDate) {
			return stringDate ? new Date(stringDate) : NaN;
		}

		function deleteTrip(tripId) {
			var dialog = dialogs.confirm('Confirmation', 'Vous allez supprimer le voyage!', {
				keyboard: true
			});
			dialog.result.then(function () {
				TripService.delete({
					tripId: tripId
				}, function (data) {
					for (var i = 0; i < vm.trips.length; i++) {
						if (vm.trips[i]._id === tripId) {
							vm.trips.splice(i, 1);
							break;
						}
					}
					toastr.success('Le voyage organisé a été supprimer avec succès', 'Succès');
				}, function (error) {
					ErrorToast(error);
				});
			});
		}

		function calculate() {
			vm.total = 0;
			vm.profit = 0;
			vm.paid_amount = 0;
			vm.purchase_price = 0;
			vm.trips = vm.trips.map(function (trip) {
				trip.total = 0;
				trip.paid_amount = 0;
				trip.profit = 0;
				trip.purchase_price = 0;
				trip.groups = trip.groups.map(function (group) {
					group.total = 0;
					group.paid_amount = 0;
					group.profit = 0;
					group.purchase_price = 0;
					group.clients.forEach(function (client) {
						if (!client.products) return;
						group.total += client.products.total || 0;
						group.paid_amount += client.products.paid_amount || 0;
						group.purchase_price += client.products.purchase_price || 0;
						group.profit += (client.products.total || 0) - (client.products.purchase_price || 0);
					});
					trip.total += group.total;
					trip.paid_amount += group.paid_amount;
					trip.profit += group.profit;
					trip.purchase_price += group.purchase_price;
					return group;
				});

				vm.total += trip.total;
				vm.profit += trip.profit;
				vm.paid_amount += trip.paid_amount;
				vm.purchase_price += trip.purchase_price;
				return trip;
			});
		}

		function newTotal() {
			vm.total = 0;
			vm.profit = 0;
			vm.paid_amount = 0;
			vm.purchase_price = 0;
			vm.filtered_trips.forEach(function (trip) {
				vm.total += trip.total;
				vm.profit += trip.profit;
				vm.paid_amount += trip.paid_amount;
				vm.purchase_price += trip.purchase_price;
				return trip;
			});
		}

		function filter() {
			if (vm.to_date && vm.from_date) {
				var to = vm.to_date.toJSON().slice(0, 10).replace(/-/g, '/');
				var from = vm.from_date.toJSON().slice(0, 10).replace(/-/g, '/');

				vm.filtered_trips = vm.trips.filter(function (trip) {
					var trip_date = new Date(trip.date).toJSON().slice(0, 10).replace(/-/g, '/');
					return trip_date >= from && trip_date <= to && (vm.selectedUsers.length > 0 ? vm.selectedUsers.includes(trip.userId) : true);
				});
				newTotal();
			} else {
				vm.filtered_trips = vm.trips.filter(function (trip) {
					return (vm.selectedUsers.length > 0 ? vm.selectedUsers.includes(trip.userId) : true);
				});
				newTotal();
			}
		}
	}
})();