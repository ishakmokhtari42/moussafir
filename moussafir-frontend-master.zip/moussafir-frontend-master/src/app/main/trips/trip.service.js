(function () {
	'use strict';

	angular
		.module('main.trips')
		.factory('TripService', TripService);

	function TripService($resource, $window) {
		var api_endpoint = $window.localStorage['host'];
		return $resource(api_endpoint + 'trips/:tripId', {
			tripId: '@id'
		}, {
			'update': {
				method: 'PUT',
				isArray: false
			}
		})
	}
})();