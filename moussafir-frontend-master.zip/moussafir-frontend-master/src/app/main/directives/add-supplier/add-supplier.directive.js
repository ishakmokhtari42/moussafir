(function () {
	'use strict';

	angular
		.module('Moussafir.main')
		.directive('addSupplier', addSupplier);

	function addSupplier(SupplierService, toastr, ErrorToast) {
		return {
			restrict: "E",
			scope: {
				supplier: "=",
				company: '=',
				suppliers: '='
			},
			templateUrl: 'app/main/directives/add-supplier/add-supplier.html',
			link: function (scope) {
				var vm = scope;

				vm.new_supplier = {
					activity: 'Plateforme B to B',
					addresses: [null],
					responsibles: [{
						addresses: [null],
						phone_numbers: [null],
						fax_numbers: [null],
						web_sites: [null],
						emails: [null],
						skypes: [null],
						faxes: [null]
					}]
				};

				vm.supplierProducts = [{
						name: "Réservation d'hôtel"
					}, {
						name: "Location"
					}, {
						name: 'Billet d\'avion'
					}, {
						name: "Agence de voyage"
					},
					{
						name: "Visa"
					}, {
						name: "Produits E-tourisme"
					}, {
						name: "Voyage Organisé"
					},
					{
						name: "Transport routier"
					}, {
						name: "Transport maritime"
					}, {
						name: "Transfert"
					}, {
						name: "Autre"
					}
				];

				vm.supplierType = supplierType;
				vm.saveSupplier = saveSupplier;
				vm.hideForm = hideForm;

				function hideForm() {
					vm.addSupplier = false;
				}

				function supplierType(supplierId) {
					var supplier = vm.suppliers.find(function (sup) {
						return sup._id === supplierId;
					});
					return supplier ? supplier.type : null;
				}

				vm.showCompany = function (company) {
					vm.company = company;
				}

				function saveSupplier() {
					if (['Plateforme B to B', 'Agence de voyage', 'Entreprise', 'Amadeus'].includes(vm.new_supplier.activity)) {
						vm.new_supplier.type = 'Intermédiaire';
					} else if (vm.new_supplier.activity !== "other") {
						vm.new_supplier.type = 'Principale';
					}
					vm.new_supplier.date = (new Date()).toISOString();
					SupplierService.save(vm.new_supplier, function (data) {
						toastr.success('Le fournisseur a été ajouter avec succès', 'Succès');
						vm.suppliers.push(data);
						if (vm.new_supplier.type === 'Principale') vm.companies.push(data);
						vm.new_supplier = {
							activity: 'Plateforme B to B',
							addresses: [null],
							responsibles: [{
								addresses: [null],
								phone_numbers: [null],
								fax_numbers: [null],
								web_sites: [null],
								emails: [null],
								skypes: [null],
								faxes: [null]
							}]
						};
					}, function (error) {
						ErrorToast(error);
					});
				}

			}
		}
	}
})();