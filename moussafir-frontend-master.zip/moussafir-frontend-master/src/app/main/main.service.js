(function () {
	'use strict';

	angular
		.module('Moussafir.main')
		.factory('ErrorToast', ErrorToast)
		.factory('PrintingNumberService', PrintingNumberService)
		.factory('NextPrintNumber', NextPrintNumber);

	function ErrorToast(toastr, $state, $window, $auth) {
		return function (response) {
			var error = response.data;
			switch (error.code) {
				case (400):
					toastr.warning("Vous devez Remplir tous les champs", 'Erreur');
					break;
				case (401):
					if (error.message === "jwt expired" || error.message === "No auth token") {
						toastr.warning("logout", 'Erreur');
						//TODO improve it
						$window.localStorage.removeItem('current_user');
						$window.localStorage.removeItem('token');
						$auth.logout();
						$state.go('auth');
					} else if (error.message === "Invalid login")
						toastr.error("Nom d'utilisateur ou mot de passe incorrecte", 'Erreur');
					break;
				case (403):
					toastr.error("Vous n'avez pas le droit d'effectuer cette opération.", 'Erreur');
					break;
				case (404):
					toastr.warning("Le contenu que vous avez demandé n'existe pas", 'Erreur');
					break;
				default:
					toastr.error('Service inaccessible pour le moment, Veuiller contacter les developpeurs!', 'Erreur');
					break;
			}
		}
	}

	function PrintingNumberService($resource, $window) {
		var api_endpoint = $window.localStorage['host'];
		return $resource(api_endpoint + 'printing-numbers/:numberId', {
			numberId: '@id'
		}, {
			'update': {
				method: 'PUT',
				isArray: false
			}
		})
	}

	function NextPrintNumber(PrintingNumberService) {
		return {
			get: get
		}

		function get(callback) {
			PrintingNumberService.query(function (data) {
				var printNumber = data[0] || {
					dailyCount: 0,
					totalCount: 0,
					date: moment().format("DD/MM/YYYY").toString()
				};
				var now = moment().format("DD/MM/YYYY").toString();

				if (now > printNumber.date) {
					printNumber.dailyCount = 0;
					printNumber.date = now;
				}

				printNumber.dailyCount++;
				printNumber.totalCount++;
				if (data.length === 0) {
					PrintingNumberService.save(printNumber);
				} else {
					PrintingNumberService.update({
						numberId: printNumber._id
					}, printNumber);
				}
				if (typeof callback === "function") callback(printNumber.dailyCount, printNumber.totalCount);
			});
		}
	}
})();