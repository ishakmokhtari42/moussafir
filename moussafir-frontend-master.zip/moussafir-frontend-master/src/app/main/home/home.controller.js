(function () {
	'use strict';

	angular
		.module('main.home')
		.controller('HomeController', HomeController);

	function HomeController() {
		var vm = this;
	}
})();