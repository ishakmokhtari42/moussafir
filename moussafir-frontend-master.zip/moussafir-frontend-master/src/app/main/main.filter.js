(function () {
	'use strict';

	angular
		.module('Moussafir.main')
		.filter('decimal', decimal);

	function decimal() {
		return function (input, places) {
			if (isNaN(input)) return input;
			var factor = "1" + Array(+(places > 0 && places + 1)).join("0");
			return ('' + (Math.floor(input * factor) / factor)).replace('.', ',');
		};
	}
})();