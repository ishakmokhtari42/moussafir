(function(){
	'use strict';

	angular
		.module('Moussafir.main')
		.controller('MainController', MainController)

	function MainController(){
		var vm = this;
	}
})();