(function () {
	'use strict';

	angular
		.module("main.products")
		.controller("DashboardController", DashboardController);

	function DashboardController(ProductService, ClientService, UserService, toastr, $window, dialogs, ErrorToast) {
		var vm = this;

		vm.products = [];
		vm.clients = [];
		vm.selectedTypes = [];
		vm.users = [];
		vm.selectedUsers = [];
		vm.filtered_products = [];
		vm.productTypes = [{
				title: "Réservation d’hôtel",
				name: 'hotel'
			},
			{
				title: "Billet d’avion",
				name: 'plane_ticket'
			},
			{
				title: "Transport routier",
				name: 'road_transport'
			},
			{
				title: "Location",
				name: 'ranting'
			},
			{
				title: "Assurance de voyage",
				name: 'travel_insurence'
			},
			{
				title: "Vente simple",
				name: 'other'
			}
		];

		ProductService.query(function (data) {
			vm.products = data;
			var current_date = new Date().toLocaleDateString();
			vm.filtered_products = vm.products.filter(function (product) {
				var product_date = new Date(product.date).toLocaleDateString();
				return current_date === product_date;
			});
			ClientService.query({
				'$select[]': 'username'
			}, function (data) {
				vm.clients = data;
				vm.products = vm.products.map(function (product) {
					product.client = getClient(product.client);
					return product;
				});
			}, function (error) {
				ErrorToast(error);
			})
		}, function (error) {
			ErrorToast(error);
		});

		UserService.query({
			'$select': ['email', 'role']
		}, function (data) {
			vm.users = data;
			for (var i = 0; i < vm.users.length; i++) {
				if (vm.users[i].role === "super-admin") {
					vm.users.splice(i, 1);
					break;
				}
			}
		}, function (error) {
			ErrorToast(error);
		});

		vm.recievedAmount = recievedAmount;
		vm.restAmount = restAmount;
		vm.profitAmount = profitAmount;
		vm.purchaseAmount = purchaseAmount;
		vm.saleAmount = saleAmount;
		vm.filter = filter;
		vm.getClient = getClient;
		vm.deleteProduct = deleteProduct;
		vm.getProductType = getProductType;

		function getProductType(type) {
			return vm.productTypes.find(function (productType) {
				return type === productType.name;
			});
		}

		function deleteProduct(productId) {
			var dialog = dialogs.confirm('Confirmation', 'Vous allez supprimer le produit!', {
				keyboard: true
			});
			dialog.result.then(function () {
				ProductService.delete({
					productId: productId
				}, function (data) {
					toastr.success('Le produit a été supprimer avec succès', 'Succès');
					for (var i = 0; i < vm.products.length; i++) {
						if (vm.products[i]._id === productId) {
							vm.products.splice(i, 1);
							break;
						}
					}
				}, function (error) {
					ErrorToast(error);
				})
			});
		}

		function recievedAmount() {
			var paid_amount = 0;
			var current_date = new Date().toLocaleDateString();
			vm.products.forEach(function (product) {
				if (!vm.showTotal && vm.to_date && vm.from_date) {
					var to = vm.to_date.toLocaleDateString();
					var from = vm.from_date.toLocaleDateString();
					if (filterExpression(product) && product.paid) {
						var last_payment = product.paid[product.paid.length - 1];
						if (last_payment) {
							var date = new Date(last_payment.date).toLocaleDateString();
							if (date >= from && date <= to)
								paid_amount += (last_payment.amount || 0);
						}
					}
				} else if (vm.showTotal) {
					paid_amount += (product.paid_amount || 0);
				} else if (filterExpression(product) && product.paid) {
					var last_payment = product.paid[product.paid.length - 1];
					if (last_payment) {
						var date = new Date(last_payment.date).toLocaleDateString();
						if (date === current_date)
							paid_amount += (last_payment.amount || 0);
					}
				}

			});
			return paid_amount;
		}

		function restAmount() {
			var rest_amount = 0;
			var products = vm.showTotal ? vm.products : vm.filtered_products;
			products.forEach(function (product) {
				rest_amount += ((product.total || 0) - (product.paid_amount || 0));
			});
			return rest_amount;
		}

		function profitAmount() {
			var profit_amount = 0;
			var products = vm.showTotal ? vm.products : vm.filtered_products;
			products.forEach(function (product) {
				profit_amount += ((product.purchase_price || 0) * (product.total_profit || 0) / 100);
			});
			return profit_amount;
		}

		function purchaseAmount() {
			var purchase_amount = 0;
			var products = vm.showTotal ? vm.products : vm.filtered_products;
			products.forEach(function (product) {
				purchase_amount += (product.purchase_price || 0);
			});
			return purchase_amount;
		}

		function saleAmount() {
			var sale_amount = 0;
			var products = vm.showTotal ? vm.products : vm.filtered_products;
			products.forEach(function (product) {
				sale_amount += ((product.purchase_price || 0) + (product.purchase_price || 0) * ((product.total_profit || 0) / 100));
			});
			return sale_amount;
		}

		function getClient(clientId) {
			return vm.clients.find(function (client) {
				return client._id === clientId
			});
		}

		function filter() {
			if (vm.to_date && vm.from_date) {
				var to = vm.to_date.toLocaleDateString();
				var from = vm.from_date.toLocaleDateString();

				vm.filtered_products = vm.products.filter(function (product) {
					var product_date = new Date(product.date).toLocaleDateString();
					return product_date >= from && product_date <= to && (vm.selectedTypes.length > 0 ? vm.selectedTypes.includes(product.type) : true) && (vm.selectedUsers.length > 0 ? vm.selectedUsers.includes(product.userId) : true);
				});
			} else {
				vm.filtered_products = vm.products.filter(function (product) {
					return
				});
			}
		}

		function filterExpression(product) {
			return (vm.selectedTypes.length > 0 ? vm.selectedTypes.includes(product.type) : true) && (vm.selectedUsers.length > 0 ? vm.selectedUsers.includes(product.userId) : true);
		}
	}
})();