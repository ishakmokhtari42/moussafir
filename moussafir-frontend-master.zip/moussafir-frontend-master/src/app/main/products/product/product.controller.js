(function () {
	'use strict';

	angular
		.module('main.products')
		.controller('ProductController', ProductController);

	function ProductController($stateParams, $state, ProductService,
		CalculationService, ClientService, SupplierService, toastr, ErrorToast) {

		var vm = this;

		vm.showHotelForm = false;
		vm.showPlaneTicketForm = false;
		vm.showShipTicketForm = false;
		vm.showInsurenceForm = false;
		vm.showOtherForm = false;
		vm.showConsulatForm = false;
		vm.showRendezVousForm = false;

		vm.new_client = {
			type: "Particulier",
			addresses: [null],
			phone_numbers: [null],
			fax_numbers: [null],
			web_sites: [null],
			emails: [null],
			passport: {}
		};

		vm.clients = [];
		vm.suppliers = [];
		vm.companies = [];

		vm.product = {};
		initProduct();

		vm.product_id = $stateParams.id;

		// if product update
		if (vm.product_id) {
			ProductService.get({
				productId: vm.product_id
			}, function (data) {
				vm.product = data;
				updateProductInfo();
				initCalculation();
			}, function (error) {
				ErrorToast(error);
			});
		} else {
			// fetch clients
			ClientService.query({
				'$select[]': 'username',
				'$sort[username]': 1
			}, function (data) {
				vm.clients = data;
			}, function (error) {
				ErrorToast(error);
			});
			initCalculation();
		}

		// fetch suppliers
		SupplierService.query({
			'$select[]': 'username'
		}, function (data) {
			vm.suppliers = data;
		}, function (error) {
			ErrorToast(error);
		});

		vm.subDates = subDates;
		vm.initProduct = initProduct;
		vm.range = range;
		vm.update = update;
		vm.updateAll = updateAll;
		vm.cancel = cancel;
		vm.save = save;
		vm.getRooms = getRooms;
		vm.updateForms = updateForms;
		vm.contains = contains;
		vm.occupant = occupant;
		vm.saveClient = saveClient;
		vm.getNights = getNights;
		vm.hotelPriceByOccupant = CalculationService.hotelPriceByOccupant;
		vm.hotelPriceByRoom = CalculationService.hotelPriceByRoom;
		vm.hotelTotalPriceByRoom = CalculationService.hotelTotalPriceByRoom;
		vm.totalPrice = CalculationService.totalPrice;
		vm.roadPriceByOccupant = CalculationService.roadPriceByOccupant;
		vm.planePriceByOccupant = CalculationService.planePriceByOccupant;
		vm.insurencePriceByOccupant = CalculationService.insurencePriceByOccupant;
		vm.ratingPriceByOccupant = CalculationService.ratingPriceByOccupant;
		vm.shipPriceByOccupant = CalculationService.shipPriceByOccupant;
		vm.totalOtherChange = totalOtherChange;
		vm.totalPrices = totalPrices;
		vm.initRecievedAmount = initRecievedAmount;
		vm.totalRecievedAmount = totalRecievedAmount;

		function initRecievedAmount() {
			var current_date = new Date();
			vm.product.paid = vm.product.paid || [{
				amount: 0,
				date: current_date
			}];
			var length = vm.product.paid.length;
			vm.product.paid[length - 1].date = new Date(vm.product.paid[length - 1].date);
			var last_recieved = new Date(vm.product.paid[length - 1].date);
			if (current_date.toLocaleDateString() > last_recieved.toLocaleDateString()) {
				vm.product.paid.push({
					amount: 0,
					date: current_date
				})
			}
			totalRecievedAmount();
		}

		function totalRecievedAmount() {
			vm.product.paid_amount = 0;
			vm.product.paid.forEach(function (payment) {
				vm.product.paid_amount += payment.amount || 0;
			});
		}

		function initProduct() {
			//Initialisation
			vm.product.occupants = [];
			vm.product.stay = {};
			vm.product.visa = {
				products: [],
				hotel: {}
			};
			vm.product.destination = "";
			vm.product.hotel = {
				nb_rooms: 1,
				occupants: {}
			};
			vm.product.plane_ticket = {
				nb_stops: 0,
				occupants: {}
			};
			vm.product.road_transport = {
				nb_stops: 0,
				occupants: {}
			};
			vm.product.ranting = {
				occupants: {}
			};
			vm.product.ship_ticket = {
				occupants: {}
			};
			vm.product.travel_insurence = {
				occupants: {}
			};
		}

		function initCalculation() {
			CalculationService.init(function () {
				return {
					product: vm.product,
					rooms: vm.rooms,
					occupant: occupant,
					showHotelForm: vm.showHotelForm,
					showPlaneTicketForm: vm.showPlaneTicketForm,
					showShipTicketForm: vm.showShipTicketForm,
					showInsurenceForm: vm.showInsurenceForm,
					showOtherForm: vm.showOtherForm,
					showConsulatForm: vm.showConsulatForm,
					showRendezVousForm: vm.showRendezVousForm
				}
			})
		}

		function totalPrices() {
			if (vm.product.type === "other") {
				if (vm.product.selling_type === "selling") {
					vm.product.purchase_price_default = Math.round(vm.product.total_default / (1 + (vm.product.total_profit / 100)));
				} else {
					vm.product.total_default = Math.round(vm.product.purchase_price_default * (1 + (vm.product.total_profit / 100)));
				}
				vm.product.purchase_price = vm.product.exchange_rate * vm.product.purchase_price_default;
				vm.product.total = vm.product.exchange_rate * vm.product.total_default;

				return vm.product.purchase_price_default;
			} else {
				return vm.totalPrice();
			}
		}

		function totalOtherChange() {
			if (vm.product.other && vm.product.other.unit_price) {
				vm.product.purchase_price_default = (vm.product.other.unit_price * vm.product.other.quantity);
			}
			return vm.product.purchase_price_default;
		}

		function range(number) {
			return new Array(number);
		}

		function subDates(from, to) {
			var nights = getNights(from, to);
			return (nights === 0) ? 0 : (nights + 1);
		}

		function getNights(from, to) {
			if (!from || !to) return 0;
			return moment.duration(moment(to).diff(moment(from))).asDays();
		}

		function update(field, name, occupants) {
			if (name === 'profit') {
				vm.product.total_profit = vm.product[field].profit;
			}
			if (vm.product[field].all & !occupants) {
				angular.forEach(vm.product[field].occupants, (function (element) {
					element[name] = vm.product[field][name];
				}));
			}
		}

		function updateAll(field) {
			if (vm.product[field].all) {
				angular.forEach(vm.product[field].occupants, (function (element) {
					element['profit'] = vm.product[field]['profit'];
					element['unit_price'] = vm.product[field]['unit_price'];
				}));
			}
		}

		function cancel() {
			$state.go("products_list");
		}

		function save(redirect) {
			(vm.product_id ? updateProduct : addProduct)(redirect);
		}

		function addProduct(redirect) {
			vm.product.date = (new Date()).toISOString();
			ProductService.save(vm.product, function (data) {
				toastr.success('Le produit a été ajouter avec succès', 'Succès');
				vm.product._id = data._id;
				vm.product_id = data._id;
				if (redirect) $state.go("products_list");
			}, function (error) {
				ErrorToast(error);
			});
		}

		function updateProduct(redirect) {
			vm.product.date = vm.product.date || (new Date()).toISOString();
			ProductService.update({
				productId: vm.product_id
			}, vm.product, function (data) {
				toastr.success('Le produit a été modifier avec succès', 'Succès');
				if (redirect) $state.go("products_list");
			}, function (error) {
				ErrorToast(error);
			});
		}

		function getRooms() {
			vm.rooms = [];
			angular.forEach(vm.product.hotel.occupants, (function (value, key) {
				if (!vm.rooms.includes(value.room_number) && value.room_number && vm.occupant(key))
					vm.rooms.push(value.room_number);
			}));
			return vm.rooms;
		}

		function updateForms() {
			vm.showHotelForm = (contains('hotel') && vm.product.visa.hotel.accommodation_type && vm.product.visa.hotel.accommodation_type !== "other");
			vm.showInsurenceForm = contains('travel_insurence');
			vm.showPlaneTicketForm = contains('plane_ticket');
			vm.showShipTicketForm = contains("ship_ticket");
			vm.showConsulatForm = contains('consulat');
			vm.showRendezVousForm = contains('rendez_vous');
			vm.showOtherForm = contains("other");
		}

		function contains(string) {
			for (var i = 0; i < vm.product.visa.products.length; i++) {
				if (vm.product.visa.products[i].name === string) {
					return true;
				}
			}
			return false;
		}

		function getDate(stringDate) {
			return stringDate ? new Date(stringDate) : NaN;
		}

		function occupant(id) {
			return vm.clients.find(function (elem) {
				return elem._id === id
			});
		}

		function updateProductInfo() {
			vm.product.stay.start_date = getDate(vm.product.stay.start_date);
			vm.product.stay.end_date = getDate(vm.product.stay.end_date);

			if (vm.product.type === 'ship_ticket') {
				vm.product.ship_ticket.departure_date_from = getDate(vm.product.ship_ticket.departure_date_from);
				vm.product.ship_ticket.departure_time_from = getDate(vm.product.ship_ticket.departure_time_from);
				vm.product.ship_ticket.arrival_date_from = getDate(vm.product.ship_ticket.arrival_date_from);
				vm.product.ship_ticket.arrival_time_from = getDate(vm.product.ship_ticket.arrival_time_from);
			}

			if (vm.product.type === 'plane_ticket') {
				vm.product.plane_ticket.departure_date_from = getDate(vm.product.plane_ticket.departure_date_from);
				vm.product.plane_ticket.departure_time_from = getDate(vm.product.plane_ticket.departure_time_from);
				vm.product.plane_ticket.arrival_date_from = getDate(vm.product.plane_ticket.arrival_date_from);
				vm.product.plane_ticket.arrival_time_from = getDate(vm.product.plane_ticket.arrival_time_from);

				vm.product.plane_ticket.departure_date_to = getDate(vm.product.plane_ticket.departure_date_to);
				vm.product.plane_ticket.departure_time_to = getDate(vm.product.plane_ticket.departure_time_to);
				vm.product.plane_ticket.arrival_date_to = getDate(vm.product.plane_ticket.arrival_date_to);
				vm.product.plane_ticket.arrival_time_to = getDate(vm.product.plane_ticket.arrival_time_to);
			}

			// fetch clients
			ClientService.query({
				'$select[]': 'username',
				'$sort[username]': 1
			}, function (data) {
				vm.clients = data;
			}, function (error) {
				ErrorToast(error);
			});

			if (vm.product.type === 'visa') {
				vm.products = vm.products.map(function (product) {
					if (contains(product.name)) {
						product.ticked = true;
					}
					return product;
				});
				updateForms();
			}
		}

		function saveClient() {
			ClientService.save(vm.new_client, function (data) {
				toastr.success('Le client a été ajouter avec succès', 'Succès');
				vm.clients.push(data);
				vm.new_client = {
					type: "Particulier",
					addresses: [null],
					phone_numbers: [null],
					fax_numbers: [null],
					web_sites: [null],
					emails: [null],
					passport: {}
				};
			}, function (error) {
				ErrorToast(error);
			});
		}
	}
})();