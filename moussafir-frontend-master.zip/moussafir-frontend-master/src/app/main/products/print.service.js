(function () {
	'use strict';

	angular
		.module('main.products')
		.factory('PrintService', PrintService);

	function PrintService($rootScope, $state, toastr, CalculationService) {
		var vm = this;

		return {
			print: print
		}

		function dateNow() {
			var d = new Date(),
				h = (d.getHours() < 10 ? '0' : '') + d.getHours(),
				m = (d.getMinutes() < 10 ? '0' : '') + d.getMinutes();
			return {
				time: h + 'h' + m,
				date: d.toLocaleDateString()
			}
		}

		function getClient(clientId) {
			return vm.clients.find(function (client) {
				return client._id === clientId
			});
		}

		function subDates(from, to) {
			var nights = getNights(from, to);
			return (nights === 0) ? 0 : (nights + 1);
		}

		function getNights(from, to) {
			if (!from || !to) return 0;
			return moment.duration(moment(to).diff(moment(from))).asDays();
		}

		function contains(string, product) {
			for (var i = 0; i < product.visa.products.length; i++) {
				if (product.visa.products[i].name === string) {
					return true;
				}
			}
			return false;
		}

		// Total price for visa, because it contains many products
		function totalVisaPrice(occupantId, product) {
			var price = 0;
			if (contains('hotel', product) && product.visa && product.visa.hotel && product.visa.hotel.accommodation_type && product.visa.hotel.accommodation_type !== "other") {
				price += CalculationService.hotelPriceByOccupant(occupantId);
			};
			if (contains('travel_insurence', product)) {
				price += CalculationService.insurencePriceByOccupant(occupantId);
			};
			if (contains('plane_ticket', product)) {
				price += CalculationService.planePriceByOccupant(occupantId);
			};
			if (contains("ship_ticket", product)) {
				price += CalculationService.shipPriceByOccupant(occupantId);
			};
			if (contains('consulat', product)) {
				price += CalculationService.consulatVisaPrice() / product.occupants.length;
			};
			if (contains('rendez_vous', product)) {
				price += CalculationService.rendezVousPrice() / product.occupants.length;
			};
			if (contains("other", product)) {
				price += CalculationService.totalOtherPrice(occupantId) / product.occupants.length;
			};
			return price;
		}


		// Table generation function
		function getOccupantTable(product, clients) {
			CalculationService.init(function () {
				return {
					product: product,
					occupant: getClient
				}
			});
			var table = {
				columns: [{
					title: 'N°',
					dataKey: 'index'
				}],
				rows: []
			};

			vm.occupants = {};
			var totalFunction;
			switch (product.type) {
				case ("hotel"):
					vm.occupants = product.hotel.occupants;
					table.columns.push({
						title: "Nté",
						dataKey: "nights"
					}, {
						title: "Nom Complet",
						dataKey: "username"
					}, {
						title: "N° Chambre",
						dataKey: "room_number"
					}, {
						title: "Type Chambre",
						dataKey: "room_type"
					}, {
						title: "Arrangement",
						dataKey: "supplement_type"
					});
					vm.voucher = product.hotel.voucher;
					vm.indication = product.hotel.indication;
					totalFunction = CalculationService.hotelPriceByOccupant;
					break;
				case ('ranting'):
					table.columns.push({
						title: "Nté",
						dataKey: "nights"
					}, {
						title: "Nom Complet",
						dataKey: "username"
					}, {
						title: "Type",
						dataKey: "occupant_type"
					});
					vm.occupants = product.ranting.occupants;
					vm.voucher = "";
					vm.indication = product.ranting.indication;
					totalFunction = CalculationService.ratingPriceByOccupant;
					break;
				case ('plane_ticket'):
					table.columns.push({
						title: "Nom Complet",
						dataKey: "username"
					}, {
						title: "Type",
						dataKey: "occupant_type"
					}, {
						title: "N° billet d'avion",
						dataKey: "number"
					});
					vm.occupants = product.plane_ticket.occupants;
					vm.voucher = "";
					vm.indication = product.plane_ticket.indication;
					totalFunction = CalculationService.planePriceByOccupant;
					break;
				case ('travel_insurence'):
					table.columns.push({
						title: "Nom Complet",
						dataKey: "username"
					}, {
						title: "Type",
						dataKey: "occupant_type"
					});
					vm.occupants = product.travel_insurence.occupants;
					vm.voucher = "";
					vm.indication = product.travel_insurence.indication;
					totalFunction = CalculationService.insurencePriceByOccupant;
					break;
				case ('road_transport'):
					vm.occupants = product.road_transport.occupants;
					vm.voucher = "";
					vm.indication = product.road_transport.indication;
					totalFunction = CalculationService.roadPriceByOccupant;
					table.columns.push({
						title: "Nom Complet",
						dataKey: "username"
					}, {
						title: "Type",
						dataKey: "occupant_type"
					}, {
						title: "Lieu Départ",
						dataKey: "departure_place"
					}, {
						title: "N° siège",
						dataKey: "seat_number"
					});
					break;
				case ('ship_ticket'):
					table.columns.push({
						title: "Nom Complet",
						dataKey: "username"
					}, {
						title: "Type",
						dataKey: "occupant_type"
					});
					vm.occupants = product.ship_ticket.occupants;
					vm.voucher = "";
					vm.indication = product.ship_ticket.indication;
					totalFunction = CalculationService.shipPriceByOccupant;
					break;
				case ('visa'):
					table.columns.push({
						title: "Nom Complet",
						dataKey: "username"
					});
					vm.occupants = product.occupants;
					vm.voucher = "";
					vm.indication = "";
					totalFunction = totalVisaPrice; //?
					break;
				case ("other"):
					table.columns.push({
						title: "Nom Complet",
						dataKey: "username"
					});
					vm.occupants = product.occupants;
					vm.voucher = "";
					vm.indication = product.other.indication;
					totalFunction = CalculationService.totalOtherPrice;
					break;
			}
			table.columns.push({
				title: "Indication",
				dataKey: "indication"
			});

			var index = 0;
			angular.forEach(vm.occupants, function (occupantDétail, id) {
				var occupant = getClient(id);
				var nights = 0;
				if (product.stay) {
					nights = getNights(product.stay.start_date, product.stay.end_date);
				}
				if (occupant) {
					table.rows.push(Object.assign({
						index: ++index,
						nights: nights,
						username: (occupant.username || ((occupant.first_name || '') + " " + (occupant.last_name || ''))),
						// total: (product.type === "other") ? (totalFunction(id) / product.occupants.length) : totalFunction(id, product)
					}, occupantDétail));
				}
			});

			return table;
		}


		// printing function
		function print(devis, dailyCount, totalCount, agency_logo, agency_info, product, clients, callback) {
			vm.clients = clients;
			try {
				var doc = new jsPDF();

				console.log(product);
				var table = getOccupantTable(product, clients);

				doc.setFont("times");
				// Agency logo
				if (agency_logo) doc.addImage(agency_logo, 'JPEG', 5, 5, 35, 35);

				// Header Text
				doc.setFontSize(16)
				doc.text(45, 13, (agency_info.name || ''));
				doc.setFontSize(12)
				doc.text(200, 13, 'Agent : ' + $rootScope.current_user.email, null, null, 'right');
				var now = dateNow();
				doc.setFontSize(13)
				doc.text(200, 20, now.date, null, null, 'right');
				doc.text(200, 27, now.time, null, null, 'right');
				doc.setFontSize(12)


				doc.text(45, 20, 'Tél : ' + (agency_info.phone || ''));
				doc.text(45, 25, 'Fax : ' + (agency_info.fax || ''));
				doc.text(45, 30, 'Adresse : ' + (agency_info.address || ''));

				// Document Title
				doc.setFontSize(25)
				doc.setFontType("bold");
				doc.text(105, 50, (devis ? 'Devis' : 'Reçu de Payment') + ' N° ' + dailyCount, null, null, 'center');

				// Product Price
				doc.setFontSize(13);
				doc.setFontType("normal");
				doc.line(0, 58, 210, 58);
				doc.text(5, 65, 'Reçu la somme de : ' + (product.paid_amount || 0) + " DZD");
				doc.text(105, 65, 'Total : ' + (product.total || 0), null, null, 'center');
				doc.text(200, 65, 'Reste : ' + (((product.total || 0) - (product.paid_amount || 0))), null, null, 'right');
				doc.line(0, 68, 210, 68);

				// Product Information
				doc.text(5, 80, 'Nom de produit : ' + (product.name || product.type));
				doc.text(5, 87, 'A partir de : ' + new Date(product.stay.start_date).toLocaleDateString());
				doc.text(200, 87, 'Jusqu\'au : ' + new Date(product.stay.end_date).toLocaleDateString(), null, null, 'right');
				doc.text(5, 94, 'Destination : ' + product.destination);

				// Client name
				doc.setFontType("bold");
				doc.text(5, 110, 'Client : ');
				doc.setFontType("normal");
				doc.text(25, 110, product.client.username);


				// Occupants names
				doc.setFontType("bold");
				doc.text(5, 120, 'Nom des occupants : ');
				doc.setFontType("normal");
				doc.line(8, 125, 200, 125);

				var occupant_number = 1;
				angular.forEach(vm.occupants, function (occupant, id) {
					if (occupant_number % 2 !== 0) {
						doc.text(15, 125 + ((parseInt(occupant_number / 2) + 1) * 10), occupant_number + '/ ' + getClient(id).username);
					} else {
						doc.text(190, 125 + (parseInt(occupant_number / 2) * 10), occupant_number + '/ ' + getClient(id).username, null, null, 'right');
					}
					occupant_number++;
				});


				var occupant_margin = 125 + (parseInt(occupant_number / 2) * 10);
				doc.line(8, (occupant_margin + 5), 8, 125);
				doc.line(200, (occupant_margin + 5), 200, 125);
				doc.line(8, (occupant_margin + 5), 200, (occupant_margin + 5));


				// Occupants Details Table Header
				doc.setFontSize(20)
				doc.setFontType("bold");
				doc.text(105, occupant_margin + 13, 'Détail d\'achat N° ' + dailyCount, null, null, 'center');
				doc.setFontSize(13)
				doc.setFontType("normal");
				doc.text(105, occupant_margin + 20, 'Liste des Personnes', null, null, 'center');

				// first page Footer
				doc.setFontSize(11);
				doc.setFontType("bold");
				doc.text(5, occupant_margin + 27, 'Numéro Téléphone: ');
				doc.setFontType("normal");
				doc.text(43, occupant_margin + 27, (product.client.phone_numbers ? product.client.phone_numbers[0] : ''));

				var table = getOccupantTable(product, clients);

				// Occupants Details Table Content
				var columns = table.columns;
				var rows = table.rows;

				var tickets_columns = [{
					title: "",
					dataKey: "sideTitle"
				}, {
					title: "Date départ",
					dataKey: "departure_date"
				}, {
					title: "Heure Départ",
					dataKey: "departure_time"
				}, {
					title: "Date d'arrivée",
					dataKey: "arrival_date"
				}, {
					title: "Heure d'arrivée",
					dataKey: "arrival_time"
				}];

				var previous = false;
				// Plane ticket details
				if (product.type === 'plane_ticket') {
					doc.setFontType("bold");
					doc.text(5, occupant_margin + 35, "Détail de Vol:");
					doc.setFontType("normal");

					tickets_columns.push({
						title: 'Aeroport Départ',
						dataKey: 'departure_airport'
					}, {
						title: 'Aeroport d\'Arrivée',
						dataKey: 'arrival_airport'
					});

					var tickets_rows = [{
						sideTitle: 'Aller',
						departure_date: new Date(product.plane_ticket.departure_date_from).toLocaleDateString(),
						departure_time: new Date(product.plane_ticket.departure_time_from).toLocaleTimeString(),
						arrival_date: new Date(product.plane_ticket.arrival_date_from).toLocaleDateString(),
						arrival_time: new Date(product.plane_ticket.arrival_time_from).toLocaleTimeString(),
						departure_airport: product.plane_ticket.departure_airport_from,
						arrival_airport: product.plane_ticket.arrival_airport_from
					}];
					if (product.plane_ticket.ticket_type === "Aller-Retour") {
						tickets_rows.push({
							sideTitle: 'Retour',
							departure_date: new Date(product.plane_ticket.departure_date_to).toLocaleDateString(),
							departure_time: new Date(product.plane_ticket.departure_time_to).toLocaleTimeString(),
							arrival_date: new Date(product.plane_ticket.arrival_date_to).toLocaleDateString(),
							arrival_time: new Date(product.plane_ticket.arrival_time_to).toLocaleTimeString(),
							departure_airport: product.plane_ticket.departure_airport_to,
							arrival_airport: product.plane_ticket.arrival_airport_to
						})
					}
					doc.autoTable(tickets_columns, tickets_rows, {
						styles: {
							fillColor: false,
							textColor: 0,
							lineColor: 0,
							font: "times"
						},
						headerStyles: {
							textColor: 0,
							lineColor: 0
						},
						tableWidth: 200,
						theme: 'grid',
						startY: occupant_margin + 37,
						margin: {
							left: 5
						}
					});

					previous = true;
				} else {
					// Ship ticket details
					if (product.type === "ship_ticket") {
						doc.setFontType("bold");
						doc.text(5, occupant_margin + 35, "Détail du transport maritime :");
						doc.setFontType("normal");


						tickets_columns.push({
							title: 'Port Départ',
							dataKey: 'departure_airport'
						}, {
							title: 'Port d\'Arrivée',
							dataKey: 'arrival_airport'
						});

						var tickets_rows = [{
							sideTitle: 'Aller',
							departure_date: new Date(product.ship_ticket.departure_date_from).toLocaleDateString(),
							departure_time: new Date(product.ship_ticket.departure_time_from).toLocaleTimeString(),
							arrival_date: new Date(product.ship_ticket.arrival_date_from).toLocaleDateString(),
							arrival_time: new Date(product.ship_ticket.arrival_time_from).toLocaleTimeString(),
							departure_airport: product.ship_ticket.departure_ship_from,
							arrival_airport: product.ship_ticket.arrival_ship_from
						}]

						doc.autoTable(tickets_columns, tickets_rows, {
							styles: {
								fillColor: false,
								textColor: 0,
								lineColor: 0
							},
							headerStyles: {
								textColor: 0,
								lineColor: 0
							},
							tableWidth: 200,
							theme: 'grid',
							startY: occupant_margin + 37,
							margin: {
								left: 5
							}
						});

						previous = true;
					}
				}
				doc.autoTable(columns, rows, {
					styles: {
						fillColor: false,
						textColor: 0,
						lineColor: 0,
						font: "times"
					},
					headerStyles: {
						textColor: 0,
						lineColor: 0
					},
					tableWidth: 200,
					theme: 'grid',
					startY: previous ? doc.autoTable.previous.finalY + 5 : occupant_margin + 30,
					margin: {
						left: 5
					}
				});


				doc.setFontSize(11);
				doc.setFontType("bold");
				if (product.type == "hotel") {
					doc.text(5, doc.autoTable.previous.finalY + 7, 'Bon Voucher : ');
					doc.text(35, doc.autoTable.previous.finalY + 7, vm.voucher || "");
				}
				doc.text(5, doc.autoTable.previous.finalY + 12, 'Indication : ');
				doc.setFontType("normal");

				doc.text(26, doc.autoTable.previous.finalY + 12, vm.indication || "");


				var codebar = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAlgAAAFKCAYAAADBkCHRAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAABt0wAAbdMBfrSbrwAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAATdEVYdFRpdGxlAFJTVlAgQmFyIENvZGUA3jonAAAKQUlEQVR4nO3ZTagdZx3H8f/RYuuiUt8wupCIQrtRIhQsurGgKC5EQTHQhS8odKngot0VFyK4sAsXBd9aoRJRNFSQiAWjqAQpNSiUFlq8iC2tr6FFm9rK30VOyGTunDNz7v1poHw+cCBz5plnZp4z59wvZNXdBQBAzkuu9AUAALzYCCwAgLCrrvQFrFarV1fVRzfsPtPdZwdjr62qW9abj3b3/VvmfWlVfWa9+cfu/vEhrvHGqrrxAIf+tLsfG831yaq6uqr+0d3fHe37YFW9YcG8D3T3A6NjP1xVr1tw7Pe6+2+D4xav6dhqtXprVb1rw+4fdPefB2Ovr6qb15u/6O6Hlp5n4rwfqarXTOz6XXf/ejR2uKZf6+7/bJn3PVX1loldyefnvu5+YsvY4ZpOPT+frgvf27929/cPcU3vq6o3Tex6obu/Php7c1Vdv9480d3ntsz7jqp6+3pz/Ay8rKo+td6cXdPBve7ime6+d2bej1XVK6vque7+1mjfm6vqvVPHdfddM/MO1/Se7n528VVfPs/wO/lId//sIPOs57p4r//q7m/PjN30G7JvTVer1Qeq6o3rzW92978PeH3XVdXxDbvHz8/Lq+rj680/dPdPZua+df3PJ7r7vpmx236Xj1XVTROHza7pzDmPVtX715vjv3XDe93FvntdrVbvrKq3LTh235quVqtbquraJefZZtv3amTfmo5+l+/t7mcG+7b1w2V/666I7r6ir6o6VlW94XXbaOzRwb4TM/NeMxh76pDXeMeWa9z2Oj4x17n1vocn9p1eOO8dE8eeWXjssYOu6cQ5P7vlPDeNxn5isO/WQ34eZzec886ZNb1mZt4TG+ZNPj/v3mFNp56f8+t9Zw95TSc33Ov5ibF3D/bfMDPvl7Y8A9ftsqaDe93ltbdg3ofXY89N7Du+ae4d1/TIIT6b4Xfy7kN+zhfv9ckFYzf9huxb06o6Ndh/3SGu74Ytn+X4+Tky2HdywdwXx55eMHbb7/JtG65vdk1nzvmhwVzjv3VHNpxz7rXvXqvqzoXH7lvTqtpbep6Ze934vZpb07r8d/noaN+2fji2yzX+L17+ixAAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAICwq670BVTV41X1uQ37fjna/vtg7CMz8z4/GLt3oCu75FRVnTvAcQ9OvHd7VV1dF+5l7KtVdXLBvGcm3vtKVb1+wbGPj7Z3WdOxn9fmz25vtP2bwdhf7XiesS9X1Wsn3v/txHvDNX1+Zt57anpt9xZf2bTh8/PozNjhmk49P5+vC9/bvxzymr5RVacn3n9h4r3vVNXZ9b+fmpn3R1X15Prfe6N9z9Zu38mL97qLpxeM+WJVvaqqnpvY92BtfqbnDNd0yXVsMvxOPnSIeaou3es/F4zd9BsydS931YXnuurC53pQT9Xy35CnB2MfWzD3xbF/WjB22+/y/VV1fuL9JWu6ze/r0jWO/9YN73UXU/f6w1r2fZta0y9U1SsWnmebpd+rqTUd/i6PP59t/TD+W/d/t+ruK30NAAAvKv6LEAAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGECCwAgTGABAIQJLACAMIEFABAmsAAAwgQWAECYwAIACBNYAABhAgsAIExgAQCECSwAgDCBBQAQJrAAAMIEFgBAmMACAAgTWAAAYQILACBMYAEAhAksAIAwgQUAECawAADCBBYAQJjAAgAIE1gAAGH/BecbCaIn2VHEAAAAAElFTkSuQmCC';


				doc.text(5, doc.autoTable.previous.finalY + 20, 'N° : ' + totalCount);
				doc.addImage(codebar, 'JPEG', 2, doc.autoTable.previous.finalY + 21, 60, 15);

				// first page Footer
				doc.setFontSize(12);
				doc.text(5, doc.autoTable.previous.finalY + 50, agency_info.footer);

				// doc.autoPrint()
				doc.save((devis ? 'Devis ' : 'Reçu ') + dailyCount + ' ' + now.date + '.pdf');
				if (typeof callback === "function") callback();
			} catch (err) {
				console.log(err);
				// if any field is missing go to product form
				$state.go('edit_product', {
					id: product._id
				});
				toastr.warning('Veuiller Remplir les informations restantes!', 'Attention');
			}
		}
	}
})();