(function () {
	'use strict';

	angular.module("main.suppliers", ['ui.select', 'ngSanitize'])
		.config(config);

	function config($stateProvider) {
		$stateProvider
			.state('suppliers', {
				parent: 'main',
				abstract: true,
				title: 'Fournisseurs',
				translate: "suppliers.main",
				sidebarMeta: {
					icon: 'ion-briefcase',
					order: 30,
				},
				loginRequired: true
			}).state('suppliers_list', {
				parent: 'main',
				url: '/suppliers/list',
				templateUrl: 'app/main/suppliers/list/suppliers.html',
				title: 'Liste Fournisseurs',
				translate: "suppliers.list",
				controller: "SuppliersController as vmSups",
				sidebarMeta: {
					order: 35
				},
				loginRequired: true
			})
			.state('add_supplier', {
				parent: 'main',
				url: '/suppliers/add',
				templateUrl: 'app/main/suppliers/supplier/supplier.html',
				title: 'Ajouter Fournisseur',
				translate: "suppliers.add",
				controller: "SupplierController",
				controllerAs: "vmSup",
				sidebarMeta: {
					order: 40
				},
				loginRequired: true
			})
			.state('edit_supplier', {
				parent: 'main',
				url: '/suppliers/edit/:id',
				templateUrl: 'app/main/suppliers/supplier/supplier.html',
				controller: "SupplierController",
				controllerAs: "vmSup",
				title: 'Modifier Fournisseur',
				translate: "suppliers.edit",
				loginRequired: true
			});
	}
})();