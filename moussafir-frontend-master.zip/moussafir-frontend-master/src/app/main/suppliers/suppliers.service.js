(function () {
	'use strict';

	angular.module('main.suppliers')
		.factory('SupplierService', SupplierService);

	function SupplierService($resource, $window) {
		var api_endpoint = $window.localStorage['host'];
		return $resource(api_endpoint + 'suppliers/:supplierId', {
			supplierId: '@id'
		}, {
			'update': {
				method: 'PUT',
				isArray: false
			}
		})
	}
})();