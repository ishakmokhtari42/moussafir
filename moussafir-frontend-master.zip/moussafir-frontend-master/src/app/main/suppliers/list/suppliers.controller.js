(function () {
	'use strict';

	angular.module('main.suppliers')
		.controller('SuppliersController', SuppliersController);

	function SuppliersController(SupplierService, ProductService, UserService, TripService, toastr, dialogs, ErrorToast) {
		var vm = this;

		vm.suppliers = [];
		vm.filteredSuppliers = [];
		vm.selectedUsers = [];
		vm.selectedTypes = [];
		vm.products = [];
		vm.supplierTypes = [
			"Agence de voyage",
			"Plateforme B to B",
			"Hôtel",
			"Compagnie aérienne",
			"Compagnie maritime",
			"Compagnie transport routière",
			"Compagnie d’assurance",
			"Entreprise",
			"Amadeus",
			"other"
		]

		vm.tripProductTypes = [
			"hotel",
			"road_transport",
			"plane_ticket",
			"ship_ticket",
			"travel_insurence",
			"ranting",
			// "visa",
			"other"
		]

		ProductService.query(function (data) {
			vm.products = data;
			TripService.query(function (trips) {
				vm.trips = trips;
				getSuppliers();
			}, function (error) {});
		}, function (error) {
			ErrorToast(error);
		});

		UserService.query({
			'$select[]': 'email',
			'$select': 'role'
		}, function (data) {
			vm.users = data;
			for (var i = 0; i < vm.users.length; i++) {
				if (vm.users[i].role === "super-admin") {
					vm.users.splice(i, 1);
					break;
				}
			}
		}, function (error) {
			ErrorToast(error);
		});

		vm.deleteSupplier = deleteSupplier;
		vm.filter = filter;
		vm.getSupplierProducts = getSupplierProducts;

		function filter() {
			vm.filteredSuppliers = vm.suppliers.filter(function (supplier) {
				return (vm.selectedTypes.length > 0 ? vm.selectedTypes.includes(supplier.activity) : true) && (vm.selectedUsers.length > 0 ? vm.selectedUsers.includes(supplier.userId) : true);
			});
		}

		function getSuppliers() {
			SupplierService.query({
				'$select': ['type', 'username', 'date','activity', 'userId']
			}, function (data) {
				vm.suppliers = data;
				vm.suppliers.forEach(function (supplier) {
					supplier.purchases = 0;
					vm.products.forEach(function (product) {
						if (product.supplier === supplier._id) {
							supplier.purchases += product.purchase_price || 0;
						}
					});
				});

				vm.trips.forEach(function (trip) {
					trip.groups.forEach(function (group) {
						angular.forEach(group, function (productMainInfo, product_name) {
							if (vm.tripProductTypes.includes(product_name)) {
								var supplier = vm.suppliers.find(function (spl) {
									return spl._id === productMainInfo.supplier;
								});
								if (supplier) {
									supplier.trips = supplier.trips || [];
									supplier.trips.push(trip);
									angular.forEach(group.clients, function (client_info) {
										angular.forEach(client_info.products, function (product, name) {
											if (product_name === name) {
												supplier.purchases = supplier.purchases || 0;
												supplier.purchases += (product.purchase_price || 0);
											}
										});
									});
								}
							}
						})
					});
				});
				vm.filteredSuppliers = vm.suppliers;
			}, function (error) {
				ErrorToast(error);
			});
		}

		function deleteSupplier(supplierId) {
			var dialog = dialogs.confirm('Confirmation', 'Vous allez supprimer le fournisseur!', {
				keyboard: true
			});
			dialog.result.then(function () {
				SupplierService.delete({
					supplierId: supplierId
				}, function (data) {
					toastr.success('Le fournisseur a été supprimer avec succès', 'Succès');
					for (var i = 0; i < vm.suppliers.length; i++) {
						if (vm.suppliers[i]._id === supplierId) {
							vm.suppliers.splice(i, 1);
							break;
						}
					}
				}, function (error) {
					ErrorToast(error);
				})
			});
		}

		function getSupplierProducts(supplier) {
			vm.supplierProducts = vm.products.filter(function (product) {
				if (product.type !== "visa") {
					return product.supplier === supplier._id;
				} else if (product.visa === null) {
					if (contains('hotel')) {
						return product.visa.hotel.accommodation_type === "other" ? (visa.hotel.supplier === supplier._id) : product.hotel.supplier === supplier._id;
					} else if (contains('travel_insurence')) {
						return product.travel_insurence.supplier === supplier._id;
					} else if (contains('plane_ticket')) {
						return product.plane_ticket.supplier === supplier._id;
					} else if (contains("ship_ticket")) {
						return product.ship_ticket.supplier === supplier._id;
					} else if (contains('consulat')) {
						return product.consulat.supplier === supplier._id;
					} else if (contains('rendez_vous')) {
						return product.rendez_vous.supplier === supplier._id;
					} else if (contains("other")) {
						return product.other.supplier === supplier._id;
					}
				}
			});

			function contains(product, string) {
				for (var i = 0; i < product.visa.products.length; i++) {
					if (product.visa.products[i].name === string) {
						return true;
					}
				}
				return false;
			}

			dialogs.create('app/main/suppliers/list/dialogs/products-dialog.html', 'SupplierProductsController', {
				products: vm.supplierProducts,
				trips: supplier.trips,
				supplier: supplier
			}, {
				keyboard: true,
				size: 'md'
			}, 'dialogVm');
		}
	}
})();