(function () {
	'use strict';

	angular.module('main.suppliers')
		.controller('SupplierController', SupplierController);

	function SupplierController($state, $stateParams, SupplierService, toastr, ErrorToast) {
		var vm = this;

		vm.user = {
			addresses: [null],
			responsibles: [{
				addresses: [null],
				phone_numbers: [null],
				fax_numbers: [null],
				web_sites: [null],
				emails: [null],
				skypes: [null],
				faxes: [null]
			}]
		};
		vm.currentRespponsible = '0';

		vm.supplier_id = $stateParams.id;

		if (vm.supplier_id) {
			SupplierService.get({
				supplierId: vm.supplier_id
			}, function (data) {
				vm.user = data;
				if (vm.user.products) {
					vm.products = vm.products.map(function (product) {
						if (contains(product.name)) {
							product.ticked = true;
						}
						return product;
					});
				}
			}, function (error) {
				ErrorToast(error);
			})
		}

		vm.translateSelect = {
			selectAll: "Tout",
			selectNone: "Aucun",
			nothingSelected: "Type Produit"
		};

		vm.products = [{
				name: "hotel"
			}, {
				name: "ranting"
			}, {
				name: 'plane_ticket'
			}, {
				name: "travel_insurence"
			},
			{
				name: "visa"
			}, {
				name: "Produits E-tourisme"
			}, {
				name: "Voyage Organisé"
			},
			{
				name: "road_transport"
			}, {
				name: "ship_ticket"
			}, {
				name: "Transfert"
			}, {
				name: "other"
			}
		];

		vm.cancel = cancel;
		vm.contains = contains;
		vm.addNewResponsible = addNewResponsible;
		vm.saveSupplier = saveSupplier;

		function saveSupplier(redirect) {
			((vm.supplier_id || vm.update) ? updateSupplier : addSupplier)(redirect);
		}

		function addSupplier(redirect) {
			if (['Plateforme B to B', 'Agence de voyage', 'Entreprise', 'Amadeus'].includes(vm.user.activity)) {
				vm.user.type = 'Intermédiaire';
			} else if (vm.user.activity !== "other") {
				vm.user.type = 'Principale';
			}
			vm.user.date = (new Date()).toISOString();
			SupplierService.save(vm.user, function (data) {
				vm.supplier_id = data._id;
				vm.user._id = data._id;
				toastr.success('Le fournisseur a été ajouter avec succès', 'Succès');
				if (redirect)
					$state.go("suppliers_list");
			}, function (error) {
				ErrorToast(error);
			});
		}

		function updateSupplier(redirect) {
			if (['Plateforme B to B', 'Agence de voyage', 'Entreprise', 'Amadeus'].includes(vm.user.activity)) {
				vm.user.type = 'Intermédiaire';
			} else if (vm.user.activity !== "other") {
				vm.user.type = 'Principale';
			}
			vm.user.date = vm.user.date || (new Date()).toISOString();
			SupplierService.update({
				supplierId: vm.supplier_id
			}, vm.user, function (data) {
				toastr.success('Le fournisseur a été modifier avec succès', 'Succès');
				if (redirect)
					$state.go("suppliers_list");
			}, function (error) {
				ErrorToast(error);
			});
		}

		function addNewResponsible() {
			vm.user.responsibles.push({
				addresses: [{}],
				phone_numbers: [null],
				fax_numbers: [null],
				web_sites: [null],
				emails: [null],
				skypes: [null],
				faxes: [null]
			});

			vm.currentRespponsible = (vm.user.responsibles.length - 1).toString();
		}

		function cancel() {
			$state.go("suppliers_list");
		}

		function contains(string) {
			for (var i = 0; i < vm.user.products.length; i++) {
				if (vm.user.products[i].name === string) {
					return true;
				}
			}
			return false;
		}
	}
})();