(function () {
	'use strict';

	angular.module('main.users')
		.controller('UsersController', UsersController);

	function UsersController(UserService, toastr, dialogs, ErrorToast) {
		var vm = this;

		vm.users = [];

		UserService.query({
			role: 'agent'
		}, function (data) {
			vm.users = data;
		}, function (error) {
			ErrorToast(error);
		});

		vm.deleteUser = deleteUser

		function deleteUser(userId, index) {
			var dialog = dialogs.confirm('Confirmation', 'Vous allez supprimer l\'utilisateur!', {
				keyboard: true
			});
			dialog.result.then(function () {
				UserService.delete({
					userId: userId
				}, function (data) {
					toastr.success('L\'utilisateur a été supprimer avec succès', 'Succès');
					vm.users.splice(index, 1);
				}, function (error) {
					ErrorToast(error);
				})
			});
		}
	}
})();