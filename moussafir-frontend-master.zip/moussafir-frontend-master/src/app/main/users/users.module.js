(function () {
	'use strict';

	angular
		.module('main.users', [])
		.config(config);

	function config($stateProvider) {
		$stateProvider
			.state('users', {
				parent: 'main',
				abstract: true,
				title: 'Agents',
				translate: "agents.main",
				sidebarMeta: {
					icon: 'ion-person',
					order: 5,
					roles: ['admin', 'super-admin']
				},
				loginRequired: true,
				adminRequired: true
			}).state('users_list', {
				parent: 'main',
				url: '/users/list',
				templateUrl: 'app/main/users/list/users.html',
				title: 'Liste des Agents',
				translate: "agents.list",
				controller: "UsersController as userVm",
				sidebarMeta: {
					order: 7,
					roles: ['admin', 'super-admin']
				},
				loginRequired: true,
				adminRequired: true
			})
			.state('add_user', {
				parent: 'main',
				url: '/users/add',
				templateUrl: 'app/main/users/user/user.html',
				title: 'Ajouter Agent',
				translate: "agents.add",
				controller: "UserController",
				controllerAs: "userVm",
				sidebarMeta: {
					order: 9,
					roles: ['admin', 'super-admin']
				},
				loginRequired: true,
				adminRequired: true
			})
			.state('edit_user', {
				parent: 'main',
				url: '/users/edit/:id',
				templateUrl: 'app/main/users/user/user.html',
				controller: "UserController",
				controllerAs: "userVm",
				// title: 'Modifier Agent',
				// translate: "agents.edit",
				// sidebarMeta: {
				// 	roles: ['admin', 'super-admin']
				// },
				loginRequired: true,
				adminRequired: true
			});
	}
})();