(function () {
	'use strict';

	angular
		.module('main.users')
		.factory('UserService', UserService);

	function UserService($resource, $window) {
		var api_endpoint = $window.localStorage['host'];
		return $resource(api_endpoint + 'users/:userId', {
			userId: '@id'
		}, {
			'patch': {
				method: "PATCH",
				isArray: false
			}
		})
	}
})();