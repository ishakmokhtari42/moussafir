(function () {
	'use strict';

	angular
		.module('main.users')
		.controller('UserController', UserController);

	function UserController($state, $stateParams, UserService, ErrorToast, toastr) {
		var vm = this;

		vm.user = {
			addresses: [{}],
			phone_numbers: [null],
			fax_numbers: [null],
			web_sites: [null],
			emails: [null],
			passport: {}
		};

		// Get state params (user id)
		vm.user_id = $stateParams.id;

		if (vm.user_id) {
			UserService.get({
				userId: vm.user_id
			}, function (data) {
				vm.user = data;
				// fixing date issues with strings
				vm.user.birthday = getDate(vm.user.birthday);
				if (vm.user.passport) {
					vm.user.passport.issue_date = getDate(vm.user.passport.issue_date);
					vm.user.passport.expiration_date = getDate(vm.user.passport.expiration_date);
				}
			}, function (error) {
				ErrorToast(error);
			});
		}

		vm.save = save;
		vm.cancel = cancel;

		function save() {
			vm.newUser.$setSubmitted();
			if (!vm.newUser.$invalid) {
				(vm.user_id ? updateUser : addUser)();
			}
		}

		function addUser() {
			vm.user.role = 'agent';
			vm.user.date = (new Date()).toISOString();
			UserService.save(vm.user, function (data) {
				toastr.success('L\'utilisateur a été ajouter avec succès', 'Succès');
				$state.go("users_list");
			}, function (error) {
				ErrorToast(error);
			});
		}

		function updateUser() {
			if (vm.user.password && !vm.changePass) {
				delete vm.user.password;
			}
			UserService.patch({
				userId: vm.user_id
			}, vm.user, function (data) {
				toastr.success('L\'utilisateur a été modifier avec succès', 'Succès');
				$state.go("users_list");
			}, function (error) {
				ErrorToast(error);
			});
		}

		function cancel() {
			$state.go("users_list");
		}

		function getDate(stringDate) {
			return stringDate ? new Date(stringDate) : NaN;
		}
	}
})();