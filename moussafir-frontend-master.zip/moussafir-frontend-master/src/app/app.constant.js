(function () {
	'use strict';

	// replaced using dynamic host
	// angular
	// 	.module('Moussafir')
	// 	.constant('API_ENDPOINT', 'http://localhost:3030/');
})();