/**
 * @author v.lugovsky
 * created on 15.12.2015
 */
(function () {
  'use strict';

  angular
    .module('Moussafir.theme', [
      'Moussafir.theme.components'
    ]);

})();