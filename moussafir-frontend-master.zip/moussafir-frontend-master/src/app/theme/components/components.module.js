(function () {
  'use strict';

  angular.module('Moussafir.theme.components', []);

})();
