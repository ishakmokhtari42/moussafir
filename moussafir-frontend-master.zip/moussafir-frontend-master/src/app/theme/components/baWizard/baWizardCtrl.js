(function () {
  'use strict';

  angular.module('Moussafir.theme.components')
    .controller('baWizardCtrl', baWizardCtrl);

  /** @ngInject */
  function baWizardCtrl($scope) {
    var vm = this;
    vm.tabs = [];

    vm.tabNum = 0;
    vm.progress = 0;

    vm.addTab = function (tab) {
      tab.setPrev(vm.tabs[vm.tabs.length - 1]);
      vm.tabs.push(tab);
      vm.selectTab(0);
    };

    $scope.$watch(angular.bind(vm, function () {
      return vm.tabNum;
    }));

    vm.selectTab = function (tabNum) {
      vm.tabs[vm.tabNum].submit();
      if (vm.tabs[tabNum].isAvailiable()) {
        vm.tabNum = tabNum;
        vm.tabs.forEach(function (t, tIndex) {
          tIndex == vm.tabNum ? t.select(true) : t.select(false);
        });
      }
    };

    vm.isFirstTab = function () {
      return vm.tabNum == 0;
    };

    vm.isLastTab = function () {
      return (vm.tabNum == vm.tabs.length - 1) && vm.tabs[vm.tabNum].show();
    };

    vm.nextTab = function () {
      var tabNum = vm.tabNum + 1;
      while (!vm.tabs[tabNum].show() && tabNum < vm.tabs.length) {
        tabNum++;
      }
      if (vm.tabs[tabNum].show()) vm.selectTab(tabNum);
    };

    vm.previousTab = function () {
      var tabNum = vm.tabNum - 1;
      while (!vm.tabs[tabNum].show() && tabNum > 0) {
        tabNum--;
      }
      if (vm.tabs[tabNum].show()) vm.selectTab(tabNum);
    };

    vm.submitCurrent = function () {
      if ((vm.tabNum!==0) && typeof vm.tabs[vm.tabNum - 1].submitCurrent === "function" && vm.tabs[vm.tabNum - 1].submitCurrent) 
        vm.tabs[vm.tabNum - 1].submitCurrent();
    };

    vm.submitAll = function () {
      if (typeof vm.tabs[vm.tabNum].submitCurrent === "function") vm.tabs[vm.tabNum].submitCurrent();
    };

    vm.calcProgress = calcProgress;

    function calcProgress() {
      return ((tabIndex() + 1) / tabLength()) * 100;
    }

    function tabLength() {
      vm.length = 1;
      vm.tabs.forEach(function (tab) {
        if (tab.show()) vm.length++;
      });
      return vm.length;

    }

    function tabIndex() {
      var tabIndex = 0;
      for (var i = 0; i < vm.tabs.length; i++) {
        if (vm.tabs[i].show()) {
          tabIndex++;
          if (vm.tabNum === i) break;
        }
      }
      if (vm.tabNum === 0 && tabLength() !== 1) return -1;
      if (vm.tabNum === vm.tabs.length - 1) return vm.tabs.length - 1;
      return tabIndex - 1;
    }
  }
})();