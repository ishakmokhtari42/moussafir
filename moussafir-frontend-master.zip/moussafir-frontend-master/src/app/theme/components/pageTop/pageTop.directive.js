/**
 * @author v.lugovksy
 * created on 16.12.2015
 */
(function () {
  'use strict';

  angular.module('Moussafir.theme.components')
    .directive('pageTop', pageTop);

  /** @ngInject */
  function pageTop($state, $window, $translate, $auth, $rootScope, baSidebarService) {
    return {
      restrict: 'E',
      templateUrl: 'app/theme/components/pageTop/pageTop.html',
      link: function (scope) {
        var language = $window.localStorage['language'];
        if (language && (language === "fr" || language === "ar")) {
          $rootScope.current_language = language;
          $translate.use(language);
        }
        scope.logout = function () {
          $window.localStorage.removeItem('current_user');
          $window.localStorage.removeItem('token');
          $auth.logout();
          $state.go('auth');
        }

        scope.changeLanguage = function (language) {
          if (language !== "fr" && language !== "ar") return;
          $window.localStorage['language'] = language;
          $rootScope.current_language = language;
          $translate.use(language);
        }

        scope.toggleMenu = function () {
          baSidebarService.toggleMenuCollapsed();
        }
      }
    };
  }

})();