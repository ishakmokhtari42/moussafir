(function () {
	'use strict';

	angular
		.module('Moussafir.theme.components')
		.directive('addButton', addButton);

	function addButton() {
		return {
			restrict: 'E',
			templateUrl: 'app/theme/components/addButton/add-button.html',
			scope:{
				array: '=ngModel',
				isLast: '=',
				object: '=',
				index: '=',
				max: '='
			},
			link: function(scope){
				var vm = scope;

				vm.array = vm.array || (vm.object ? [{}] : [null]);

				vm.pushElement = function(){
					vm.array.push(vm.object ? {} : null); 
				}
			}
		}
	}
})();