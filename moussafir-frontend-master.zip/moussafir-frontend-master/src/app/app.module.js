(function () {
  'use strict';

  angular.module('Moussafir', [
    'ngAnimate',
    'ngCookies',
    'ui.bootstrap',
    'ui.router',
    'ngTouch',
    'toastr',
    'ngResource',
    'ui.slimscroll',
    'toastr',
    'isteven-multi-select', //to be removed
    'ui.multiselect', //being improved
    'dialogs.main',
    'ngMap',
    'pascalprecht.translate',

    'Moussafir.host',
    'Moussafir.key',
    'Moussafir.auth',
    'Moussafir.theme',
    'Moussafir.main'
  ]);
})();